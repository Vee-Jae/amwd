<?php
$server = "localhost";
$username = "thevclo_V33dm1n";
$password = "6(Xk4_EQ^X6x";
$database = "thevclo_@mwd";

// Create connection and Check connection
$conn = mysqli_connect($server, $username, $password) or die("Error in connection!");
mysqli_select_db($conn, $database ) or die("Could not select database");

date_default_timezone_set('Asia/Manila');

?>

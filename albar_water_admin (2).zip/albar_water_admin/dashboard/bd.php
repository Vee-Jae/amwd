<?php
$servername = "localhost";
$username = "thevclo_V33dm1n";

$password = "6(Xk4_EQ^X6x";
$dbname = "thevclo_@mwd";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

 
?>
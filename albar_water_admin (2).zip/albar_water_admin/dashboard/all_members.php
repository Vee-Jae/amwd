<section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
            <?php
            if (!isset($_GET['dat']))
            {
                echo "List of all Customers" ;
            }
            else
            {
                if ($_GET['dat']==1 )
                {
                    echo "Users With Package" ;
                }
                else
                {
                    echo "Users Without Package" ;
                }
            }
            
            ?>
        </h4>
     
                <table id="example1" class="table table-bordered table-hover">
              <thead>
                  <tr>
                  <th  > </th>
                  <th  > #</th>

                      <th  >Account #</th>
                      <th >Full name</th>
                      <th >Account Holder.</th>
                      <th >Unpaid Balance</th>                   
                       <th >Line Status</th>
                      <th >Action</th>
                 </tr>
              </thead>
              <tbody>
                  <?php
                   if (!isset($_GET['dat']))
                   {
                        $result = mysqli_query($conn , "SELECT * FROM tbl_user_account order by unique_id desc");
                   }
                    $cnt = 0 ;
                    while( $row = mysqli_fetch_array($result) )
                    {
                        $cnt++;

                  ?>
                  <tr>
                  
                      <td><?php echo $row['unique_id'] ?></td>
                      
                      <td  ><?php echo $row['firstname'] . ' ' .$row['lastname'] ?></td>
                      <td  >
                         <?php echo $row['acct_holder'] ?>
                                        
                    </td>
                  
                     
                     
                     <td>  <?php
 $unique_id=  $row['unique_id'] ;

$sql_user_readings1 = "SELECT sum(balance) as remainingbalance FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc";
$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
$row_user_readings3 = mysqli_fetch_assoc($result_user_details2);

$remainingbalance = $row_user_readings3['remainingbalance'];

if ($remainingbalance > 0) {
 
 echo ' <b style="color:red">&#8369;'.$remainingbalance.  '</b>';


 
}else {

  echo ' <b text-sucess >&#8369;'.$remainingbalance.  '</b>';


}

                     
                     ?> 
                      </td>
                   

                         <td>

                         <?php
                         $linestatus = $row['line_status'] ;
                         if ($linestatus == 0) {
 
 echo '<a href="upgrade.php?mid='.$row['id'].'&&pkg='.$row['package'].'" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #df2525;
    border-radius: 10px; font-weight: bold; font-size: 10px;    ">Disconnected</a>';



}elseif  ($linestatus== 1) {
  echo '<a href="#" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
  border-radius: 10px; font-weight: bold; font-size: 10px;    ">Connected</a>';


}
  ?>
  </td>
                     
                      <td>
                     

                      <a href="encode_reading.php?mid=<?php echo $row['unique_id'] ?>" 
                      class="btn btn-outline-primary btn-radius" > <i class="fas fa-tachometer-alt"></i> </a>

                      
                      <a href="index.php?mid=<?php echo $row['unique_id'] ?>" type="button" data-table="product1"  data-toggle="modal" data-target="#printcheckmodal"  class="btn btn-outline-danger btn-radius" > 
                      <i class="fas fa-money-bill-alt"></i> </a>
      

                     
                      <a href="profile.php?mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-dark btn-radius" > 
                      <i class="fas fa-edit"></i> </a>
                      
                      <a href="#" type="button"  data-toggle="modal" data-target="#requestModal" class="btn btn-outline-danger btn-radius" > <i class="fas fa-trash-alt"></i> </a>
                     
                     <a href="prevtransactions.php?mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-dark btn-radius" > 
                      <i class="fas fa-history"></i>
     

                   


 

                      <div class="modal" id="requestModal">
            <div class="modal-dialog">
              <div class="modal-content btn-radius">
                <div class="modal-header pb-0" style="border: 0px;">
                  <h5 class="modal-title" style="font-weight: bold;">Remove Account</h5>
                </div>
                <div class="modal-body pt-0 pb-0">
                  <p class="text-muted">Are you sure you want to Remove This account?</p>
                </div>
                <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                  <div class="row">
                    <div class="col-6">
                      <button type="button" class="btn btn-default btn-block btn-save bg-white" data-dismiss="modal">Cancel</button>
                    </div>
                    <div class="col-6">
                   <form>
                    <input type="hidden" name="save_data" value="<?php echo $row['id'] ?>">
                  
                      <input type="hidden" name="save_data" value="save">
                      <button type="submit" id="action" class="btn btn-success btn-save btn-block">
                        <span id="button-text">Yes, Submit</span>
                      </button>

</form>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>

                      
                      
                      
                    </td>
                  </tr>
                  <?php
                    }
                  ?>
              </tbody>
              
          </table>
        </div>



       
      </div>
    </div>
  </div>

</div>
</section>
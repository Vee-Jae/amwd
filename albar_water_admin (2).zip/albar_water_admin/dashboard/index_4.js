$(document).on("click", "#btn-add", function (e) {
  var data = $("#user_form").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "all_members_save.php",
    success: function (dataResult) {
      var dataResult = JSON.parse(dataResult);
      if (dataResult.statusCode == 200) {
        $("#addEmployeeModal").modal("hide");
        swal("Good job!", "Data Saved !", "success");
        setTimeout(200000);
        location.reload();
      } else if (dataResult.statusCode == 201) {
        //alert(dataResult);
        swal("Error!", "Could'not be saved !", "warnings");
        setTimeout(2000);
      }
    },
  });
});




 

//add other balances
$(document).on("click", ".addmorebalance", function (e) {
  var id1 = $(this).attr("data-acc");
  var acctholder1 = $(this).attr("data-name");
 

  $("#id_u_reading").val(id1);
   $("#txt_acct_holder1").val(acctholder1);
 
 
});



//add bills payment
$(document).on("click", ".addpayment", function (e) {
  var id = $(this).attr("data-id");
  var acctholder = $(this).attr("data-name");

  $("#id_u").val(id);
  $("#id_u2").val(id);
  $("#txt_acct_holder").val(acctholder);
 
});

 


$(document).on("click", "#btn-addbillspayment", function (e) {
  var data = $("#user_form_billspayment").serialize();
  
  $.ajax({
    data: data,
    type: "post",
    url: "all_members_save.php",
    success: function (dataResult) {
      var dataResult = JSON.parse(dataResult);
      if (dataResult.statusCode == 200) {
        $("#addPaymentModal").modal("hide");
         swal("Good job!", "Data Saved !", "success");
        setTimeout(5000);
        window.location = 'printlogs.php';
      
      
      
      
      } else if (dataResult.statusCode == 201) {
        //alert(dataResult);
        swal("Error!", "Could'not be saved !", "warnings");
        setTimeout(5000);
      }
    },
  });
});
 



//add meter reading
$(document).on("click", ".addmeterreading", function (e) {
  var id1 = $(this).attr("data-accountno");
  var acctholder1 = $(this).attr("data-name");
  var prevreading = $(this).attr("data-prevreading");

  $("#id_u_reading").val(id1);
 
  $("#txt_acct_holder1").val(acctholder1);
  $("#id-1").val(prevreading);
 
});


$(document).on("click", "#btn-addmeterreading", function (e) {
  var data = $("#user_form_meterreading").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "all_members_save.php",
    success: function (dataResult) {
      var dataResult = JSON.parse(dataResult);
      if (dataResult.statusCode == 200) {
        $("#addmetertModal").modal("hide");
        swal("Good job!", "reading Saved !", "success");
        setTimeout(5000);
        window.location = 'printlogs_reading.php';
      } else if (dataResult.statusCode == 201) {
        //alert(dataResult);
        swal("Error!", "Could'not be saved !", "warnings");
        setTimeout(5000);
      }
    },
  });
});



$(document).on("click", "#btn-meterpayment", function (e) {
  var data = $("#user_form_meterdevicepayment").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "all_members_save.php",
    success: function (dataResult) {
      var dataResult = JSON.parse(dataResult);
      if (dataResult.statusCode == 200) {
        $("#user_form_meterdevicepayment").modal("hide");
        swal("Good job!", "Meter Device Payment Submitted!", "success");
        setTimeout(5000);
        window.location = 'printlogs.php';
      } else if (dataResult.statusCode == 201) {
        //alert(dataResult);
        swal("Error!", "Could'not be saved !", "warnings");
        setTimeout(5000);
      }
    },
  });
});
 
 

 


$(document).on("click", ".update", function (e) {
  var id = $(this).attr("data-id");
  var name = $(this).attr("data-name");
  var email = $(this).attr("data-email");
  var phone = $(this).attr("data-phone");
  var city = $(this).attr("data-city");
  var fname = $(this).attr("data-fname");
  var lname = $(this).attr("data-lname");
  var sponsor = $(this).attr("data-sponsor");
 
  $("#id_u").val(id);
  $("#name_u").val(name);
  $("#email_u").val(email);
  $("#phone_u").val(phone);
  $("#city_u").val(city);

  $("#sponsor_u").val(sponsor);
  $("#lname_u").val(lname);
  $("#fname_u").val(fname);
});


 

 

$(document).on("click", "#update", function (e) {
  var data = $("#update_form").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "all_members_save.php",
    success: function (dataResult) {
      var dataResult = JSON.parse(dataResult);
      if (dataResult.statusCode == 200) {
        $("#editEmployeeModal").modal("hide");
        swal("Good job!", "Data Updated Successfully!", "success");
        setTimeout(2000);
        location.reload();
      } else if (dataResult.statusCode == 201) {
        swal("Error!", "Could'not be Updated !", "Warnings");
        setTimeout(2000);
      }
    },
  });
});

$(document).on("click", ".delete", function () {
  var recordid = $(this).attr("data-id");
  swal({
    title: "Are you sure?",
    text: "Once deleted, you will not be able to recover this Record!!!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "all_members_save.php",
        type: "POST",
        cache: false,
        data: {
          type: 3,
          id: recordid,
        },
        success: function (dataResult) {
          location.reload();

          $("#" + dataResult).remove();
        },
      });
      swal("Record Deleted successfully !", {
        icon: "success",
      });
    } else {
      swal("Your record is safe");
    }
  });
});


$(document).on("click", "#delete_multiple", function () {
  var user = [];
  $(".user_checkbox:checked").each(function () {
    user.push($(this).data("user-id"));
  });
  if (user.length <= 0) {
    alert("Please select records.");
  } else {
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this Record !",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        var selected_values = user.join(",");
        //console.log(selected_values);
        $.ajax({
          type: "POST",
          url: "all_members_save.php",
          cache: false,
          data: {
            type: 4,
            id: selected_values,
          },
          success: function (response) {
            var ids = response.split(",");
            for (var i = 0; i < ids.length; i++) {
              $("#" + ids[i]).remove();
            }
          },
        });
        location.reload();
        swal("Record Deleted successfully !", {
          icon: "success",
        });
      } else {
        swal("Cancelled! Your data is safe!");
      }
    });
  }
});
$(document).ready(function () {
  $('[data-toggle="tooltip"]').tooltip();
  var checkbox = $('table tbody input[type="checkbox"]');
  $("#selectAll").click(function () {
    if (this.checked) {
      checkbox.each(function () {
        this.checked = true;
      });
    } else {
      checkbox.each(function () {
        this.checked = false;
      });
    }
  });
  checkbox.click(function () {
    if (!this.checked) {
      $("#selectAll").prop("checked", false);
    }
  });
});

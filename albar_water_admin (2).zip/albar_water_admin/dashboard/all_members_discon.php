 
  
 
        <div class="inner">
            <h4 style="mx-auto" >
            Disconnected <b>Accounts</b> 
        </h4>
	 
                <table id="example_discon"  class="table table-striped table-bordered table-sm table-hover" cellspacing="0" width="100%">
             
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th> 
				 
                 
						
					  <th  >Account</th>					
                   
                      <th >Account_holder</th>
					  <th> MD_Balance
					 
                      <th >WB Balance</th>                   
                       <th >Status</th>
                      <th width="20%" >Action</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php
				$result = mysqli_query($conn,"SELECT * FROM tbl_user_account where line_status = 0 order by unique_id desc");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr 
				<?php

$unique_id=  $row['unique_id'] ;

$sql_cntallread= "SELECT count(*) as totalreadingcnt from tbl_members_report where account_no = '$unique_id'";
$result_cntallread= mysqli_query($conn, $sql_cntallread);
$row_totalcnt = mysqli_fetch_assoc($result_cntallread);
$totalreadingcount =  $row_totalcnt ["totalreadingcnt"];	
//4



$sql_cntallread2= "SELECT count(*) as totalpaymentmade FROM `tbl_payments` where unique_id = '$unique_id'";
$result_cntallread2= mysqli_query($conn, $sql_cntallread2);
$row_totalcnt2 = mysqli_fetch_assoc($result_cntallread2);
$totalpaymentmade =  $row_totalcnt2 ["totalpaymentmade"];	
//4 

if ($totalreadingcount >= 3) {

	//check if bayad n sya ng tatlo muna 
	if ($totalreadingcount  > $totalpaymentmade ) {
		
		$count_difference = $totalreadingcount -$totalpaymentmade;
			if ($count_difference == 1 ) {
			echo 'style="background: #fff;color: #000;';
			}elseif ($count_difference == 2 ) {
				echo 'style="background: #118134;color: #fff;';
			}elseif ($count_difference >= 3 ) {
				echo 'style="background: #c23d3d;color: #fff;';
		 
			}else{

			}

	//	echo $totalreadingcount .' - '. $totalpaymentmade;
	}else {
		//echo $totalreadingcount .' - '. $totalpaymentmade;
	}



} 
?>
id="<?php echo $row["id"]; ?>">
				
				<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td>
					 


   <!--START OLD TABLE-->

   					<td><?php echo $row['unique_id'] ?></td>                    
                     
                      <td  >   <?php echo $row['acct_holder'] ?>
                                        
                    </td>
                  
                     <td>
						<?php
						$unique_id=  $row['unique_id'] ;
						$sql_user_billrecord= "SELECT SUM(amount) as feepaidbalances FROM tbl_payments where payment_type = 'MD' and unique_id = '$unique_id'";
						$result_user_billpay= mysqli_query($conn, $sql_user_billrecord);
						$row_user_billpay_summary = mysqli_fetch_assoc($result_user_billpay);
						
						$sql_user_readings1 = "SELECT sum(fee) as totalfee FROM tbl_meterdevice where account_no = '$unique_id' ";
						$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
						$row_user_readings_summary = mysqli_fetch_assoc($result_user_details2);
						
						$remainingbalance_summary = $row_user_readings_summary['totalfee'];
						$billspayment_summary = $row_user_billpay_summary['feepaidbalances'];
						
						$totalmeterfee = $remainingbalance_summary - $billspayment_summary;
						
								if ($totalmeterfee > 0) {
								
									echo ' <b style="color:red">&#8369;'.$totalmeterfee.  '</b>';
								
								
									
								}else {
								
									echo ' <b text-sucess >&#8369; 0.00 </b>';
								
								
								}
														
						?>
					</td>
                     
                     <td>  <?php
 $unique_id=  $row['unique_id'] ;
//$sql_user_readings1 = "SELECT (SELECT SUM(`billing_amount`) FROM tbl_members_report  where account_no = '$unique_id' ) - (SELECT SUM(amount) FROM tbl_payments where unique_id = '$unique_id') AS total_billbalance";

//get bill payments  records
$sql_user_billrecord= "SELECT SUM(amount) as billspaidbalances FROM tbl_payments where unique_id = '$unique_id' and payment_type = 'WB'";
$result_user_billpay= mysqli_query($conn, $sql_user_billrecord);
$row_user_billpay = mysqli_fetch_assoc($result_user_billpay);

$sql_user_readings1 = "SELECT sum(billing_amount) as totalbills FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc";
$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
$row_user_readings3 = mysqli_fetch_assoc($result_user_details2);
$wpblance = $row_user_readings3['totalbills'] ;

$sql_user_bklogs = "SELECT sum(amount) as bklogtotal FROM tbl_backlogs_collection where account_no = '$unique_id' ";
$result_bl_details2 = mysqli_query($conn, $sql_user_bklogs);
$row_user_bklogread = mysqli_fetch_assoc($result_bl_details2);
$bklog = $row_user_bklogread['bklogtotal'];


$remainingbalance = $wpblance  + $bklog;
$billspayment = $row_user_billpay['billspaidbalances'];

 
$billspayment = $row_user_billpay['billspaidbalances'];

$totalunpaidbill = $remainingbalance - $billspayment;
if ($totalunpaidbill > 0) {
 
 echo ' <b style="color:red">&#8369;'.$totalunpaidbill.  '</b>';


 
}else {

  echo ' <b text-sucess >&#8369; 0.00 </b>';


}

                     
                     ?> 
                      </td>
                   

                         <td>

                         <?php
                         $linestatus = $row['line_status'] ;
                         if ($linestatus == 0) {
 ?>
 <a href="connection.php?con=1&&mid=<?php echo $row['unique_id'] ?>" 
 class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #df2525;
    border-radius: 10px; font-weight: bold; font-size: 10px;    ">Disconnected</a>

<?php

}elseif  ($linestatus== 1) {
 ?><a href="connection.php?con=0&&mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
  border-radius: 10px; font-weight: bold; font-size: 10px;    ">Connected</a> 
<?php

}
  ?>
  </td>
                     
                      <td>
                     
					 <!-- <a href="#addotherbalance" class="addmorebalance btn  btn-outline-dark"
					     	data-acc="<?php echo $row["unique_id"]; ?>"
							data-name="<?php echo $row["acct_holder"]; ?>"
							data-prevreading="<?php echo $row['pres_reading']; ?>"							
 							title="addmorebalance"
							 data-toggle="modal"> 
										
							 <i class="fas fa-plus-circle"></i> </a>  -->

<?php if ($row['new_meter'] == 1) {?>


 <a href="#" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
  border-radius: 10px; font-weight: bold; font-size: 10px;    ">
  <i class="fas fa-infinity"></i>
</a>

<?php }else {
	?>

<a href="resetconnection.php?con=0&&mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #c5c5c5;
  border-radius: 10px; font-weight: bold; font-size: 10px;    ">
 <i class="fas fa-infinity"></i>
</a> 


<?php } ?>


							 <a href="addmorebalance.php?mid=<?php echo $row["unique_id"];?>" class="addmorebalance btn  btn-outline-dark">
							 	 <i class="fas fa-plus-circle"></i> </a>


				

					  <a href="#addmetertModal" class="addmeterreading btn  btn-outline-dark"
					     	data-accountno="<?php echo $row["unique_id"]; ?>"
							data-name="<?php echo $row["acct_holder"]; ?>"
							data-prevreading="<?php echo $row['pres_reading']; ?>"							
 							title="addmeterreading1"
							 data-toggle="modal"> 
							<i class="fas fa-tachometer-alt"data-toggle="tooltip"></i> </a>  


					  <a href="#addPaymentModal" class="addpayment btn  btn-outline-warning" 
					  		data-id="<?php echo $row["unique_id"]; ?>"
							data-name="<?php echo $row["acct_holder"]; ?>"
						 	title="addpayment1" 
							data-toggle="modal"> 

							<i class="fas fa-money-bill-alt"data-toggle="tooltip"></i> </a>  
      

					
 
                    <!-- <a href="prevtransactions.php?mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-dark btn-radius" > 
                      <i class="fas fa-history"></i> -->
					  <a href="#deleteEmployeeModal" class="delete btn btn-danger btn-radius" data-id="<?php echo $row["id"]; ?>" data-toggle="modal">
						<i class="fas fa-trash-alt" data-toggle="tooltip" 
						 title="Delete"></i></a>
</td>


                      <!--END OLD TABLE-->
					 
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
	 
        </div> 

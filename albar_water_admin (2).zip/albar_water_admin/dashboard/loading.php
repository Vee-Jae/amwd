<?php
 session_start();
 include('../connect.php');
 include('sql_details.php');
 

 
if (empty($_SESSION['username'])) {
    header('location: ../index.php');
}

if ($_SESSION['username'] == 'admin') {
  header('location: indexcollection.php');   
}else {
  header('location: index.php');    
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Loading</title>
  <link rel="shortcut icon" type="image/x-icon" href="images/logo.png">
    <link rel="icon" type="image/png" href="../images/logo_storerunner.png"/>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/style1.css">
</head>
<style type="text/css">
  .form-control:focus {
    border: 1px solid #eb8810!important;  
    box-shadow: none!important;
}
#loading {
  background: rgba( 255, 255, 255, 0.8 );
  display: none;
  height: 100%;
  position: fixed;
  width: 100%;
  z-index: 9999;
}

#loading img
{
  left: 52%;
  margin-left: -32px;
  margin-top: -32px;
  position: absolute;
  top: 50%;
}

@media(max-width: 800px) {
  #loading img{
      left: 54%!important;
  }
}

@media(min-width: 801px) {
  #loading img {
    display: none!important;
  }
  #loading {
    display: none!important;
  }
}
</style>
<body>
<div>
  <div id="preloader"></div>
  <script>
    //Using setTimeout to execute a function after 5 seconds.
    setTimeout(function () {
       //Redirect with JavaScript
     window.location.href = 'index.php?<?php echo generate_string($permitted_chars, 100) ?>&&<?php echo generate_string($permitted_chars, 100) ?>&&<?php echo generate_string($permitted_chars, 100) ?>';
    }, 1000);
  </script>
</div>  
<script src="js/jquery-3.2.1.min.js"></script>
<script src="plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="plugins/jquery-validation/additional-methods.min.js"></script>
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>

</body>
</html>
 


 

	<p id="success"></p>
 
  
  
     <section class="content">

         
                                                  

  <div class="container-fluid">

  <label for="datepost">Select Reading Date:</label>
           
            <form action="" method= "POST">
            <select  class="form-control" name="select_readingdate"  aria-label="Default select example">
              <option value="" disabled>Select Date</option>
              <?php    if (!isset($_GET['dat']))
                   {
                        $result = mysqli_query($conn , "SELECT * FROM tbl_reading_sched order by  id desc");
                   }
                    $cnt = 0 ;
                    while( $row = mysqli_fetch_array($result) )
                    {
                        $cnt++;

                        ?>
                       
                         <option value="<?php echo $row['reading_date'] ?>"><?php echo $row['reading_date']  ?></option>
                <?php } ?>
             </select>
             <button type="submit" class="btn btn-primary btn-radius btn-block btn-multi text-white" name="submitcompletereading">Generate Report</button>
					
              </form>
    
      <div class="col-lg-12 col-12">
        <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
          <div class="inner">
              <h5 style="mx-auto" >
                <b>Reading Date:   <?php echo $generateddate .' count: '. number_format(($completedreadingcount))." | &#8369;" .number_format(($totalreadsum));  ?>
                </b>
          </h5>
  
       
                  <table id="example1"  class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
               
                  <thead>
                      <tr>
                     
                   
                          <th  >#</th>
                          
                        <th  >Account</th>					
                        <th >reading_date</th>
                        <th> account_name</th> 
                         <th >prev_reading</th>                   
                         <th >pres_reading</th>
                         <th >total_reading</th>
                         <th >billing_amount</th>
                         <th >Status</th>
                        <th width="20%" >Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  
                  <?php
   
                  $result = mysqli_query($conn,"SELECT* from tbl_members_report LEFT JOIN tbl_user_account ON tbl_members_report.account_no  = tbl_user_account.unique_id  where tbl_members_report.reading_date= '$generateddate' and tbl_user_account.line_status = 1 ;");
               

                  
                  $i=1;
                      while($row = mysqli_fetch_array($result)) {
  
                      $reading_date      =	$row['reading_date'] ;
                      $transaction_date    =	$row['transaction_date'] ;
                      $account_no      =	$row['account_no'] ;
                      $account_name       =	$row['account_name'] ;
                      $prev_reading   =	$row['prev_reading']; 
                      $pres_reading   =	$row['pres_reading'] ;
                      $total_reading   =	$row['total_reading']; 
                      $billing_amount =	$row['billing_amount'] ;
                      $due_date =	$row['due_date'] ;
                      $disconnection_date =	$row['disconnection_date'] ;
                       
  
                   
                  ?>
               <tr id="<?php echo $i; ?>"> 
           
                       
                          <td><?php echo $i; ?></td>  
  
     <!--START OLD TABLE-->
  
                         <td><?php echo $row['account_no'] ?></td>                    
                       
                        <td  >   <?php echo $row['reading_date'] ?>  </td>
                    
                       <td>   <?php echo $row['account_name'] ?>	</td>
                       
                       <td> <?php echo $row['prev_reading'] ?>   
                        </td>
                        <td> <?php echo $row['pres_reading'] ?>   
                        </td>
                     
  
                           <td>  <?php echo $row['total_reading'] ?>  </td>
                           <td>  <?php echo $row['billing_amount'] ?>  </td>
                       
                       <td> <?php
                         $linestatus = $row['line_status'] ;
                         if ($linestatus == 0) {
                          ?>
                          <a href="connection.php?con=1&&mid=<?php echo $row['unique_id'] ?>" 
                          class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #df2525;
                              border-radius: 10px; font-weight: bold; font-size: 10px;    ">Disconnected</a>

                          <?php

                          }elseif  ($linestatus== 1) {
                          ?><a href="connection.php?con=0&&mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
                            border-radius: 10px; font-weight: bold; font-size: 10px;    ">Connected</a> 
                          <?php

                          }
                            ?> 
                            </td> <td> <a href="printreceipt_reading.php?mid=<?php echo $account_no; ?>&&acctholder=<?php echo $account_name;?>&&pres_reading=<?php echo $pres_reading;?>&&prev_reading=<?php echo $prev_reading;?>&&total_reading=<?php echo $total_reading;?>&&billing_amount=<?php echo $billing_amount;?>&&reading_date=<?php echo $reading_date;?>&&duedate=<?php echo $due_date;?>&&disconnection=<?php echo $disconnection_date;?>"><i class="fas fa-print"></i> </a></td>
  
  
                        <!--END OLD TABLE-->
                       
                  </tr>
                  <?php
                  $i++;
                  }
                  ?>
                  </tbody>



                  <tfoot id="example1" class="table-dark">
          	  <tr>
				<th></th>
				<th></th>
				
				 <th scope="row"></th>
     
                <td> 
		
					 
					</td>

 
					<td>  
					 
					</td>
					<td> </td>
          <td>Total </td>
          <td>		<?php
					 
					 $sumgc = "SELECT sum(billing_amount) as totalbill from tbl_members_report LEFT JOIN tbl_user_account ON tbl_members_report.account_no  = tbl_user_account.unique_id  where tbl_members_report.reading_date= '$generateddate' and tbl_user_account.line_status = 1 ;";
					 $result_sumgc= mysqli_query($conn, $sumgc);
					 $rowgcsum = mysqli_fetch_assoc($result_sumgc);
					 
					 echo   number_format(($rowgcsum['totalbill']));
					 
					 ?> </td>
					 
					 <td> </td>
          <td> </td>
                    

            </tr>
       		 </tfoot>

           
              </table>
       
          </div>
      </div>
</section>
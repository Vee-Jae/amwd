<?php 
 require_once('../connect.php');


if (isset($_POST['search_action'])) {
  if ($_POST['search_action'] == 'search_member') {
    $search = mysqli_real_escape_string($conn, $_POST['search']);

    $sqlSearch = "SELECT * FROM tbl_user_account WHERE (firstname LIKE '%$search%' OR lastname LIKE '%$search%')";
    $resultSearch = $conn->query($sqlSearch);
    if ($resultSearch->num_rows > 0) {
      while($rowSearch = mysqli_fetch_array($resultSearch)) {
        echo '<li class="list-group-item link-class" data-member-id="'.$rowSearch['unique_id'].'" data-member-name="'.$rowSearch['firstname'].' '.$rowSearch['lastname'].'">
                <span>'.$rowSearch['firstname'].' '.$rowSearch['lastname'].'</span>
              </li>';
      }

      echo '<script type="text/javascript">
              $(document).ready(function() {
                $(".link-class").click(function(){
                  var member_id = $(this).attr("data-member-id");
                  var member_name = $(this).attr("data-member-name");
                  $("#search").val(member_name);
                  $("#member_id").val(member_id);
                  $("#result").hide();
                });
              });
            </script>';
    }else{
      echo 0;
    }
  }
}

?>




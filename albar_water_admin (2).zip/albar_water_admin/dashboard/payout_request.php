<?php
 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 $datetoday = date('Y-m-d'); 
$active_tab = "payout";
if (!isset($_SESSION['unique_id'])) { ?>
<script language="javascript">
window.location.href = '../index.php';
</script>
<?php }

$success_messages = '';
if (isset($_POST['approve'])) {
  $id = $_POST['id'];
  $amount = $_POST['total_credit'];
  $user_id = $_POST['unique_id'];
  $thenetpaid = $_POST['thenetpaid'];
 
  function generateRandomString($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
  }

  $transaction_num = 'WT'.generateRandomString();

  $sql_update_request = "UPDATE tbl_request_encashment SET status = '1', net = '$thenetpaid', date_approve = '$datetoday' WHERE id = '$id'";
  if (mysqli_query($conn, $sql_update_request)) {
    $sql_insert_credit = "INSERT INTO tbl_hybrid_bonus(unique_id, debit, credit, bonus_type, transaction_type, date_accumulated, verification_code) VALUES('$user_id', '0', '$amount', 'ENC', 'WT', '$datetoday', '$transaction_num')";
    if (mysqli_query($conn, $sql_insert_credit)) {
          $success_messages = '<div class="alert alert-success text-center mb-0">Request Successfully Approve.</div>';
    }
  }
}

?>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Payout Request</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link rel="icon" href="images/logo.png" type="image/png" sizes="16x16">
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <link rel="stylesheet" type="text/css" href="css/skeleton_loading.css">
    <style type="text/css">
    .content-wrapper {
        background: #151e27 !important;
    }

    @media(max-width:800px) {
        .modal-content {
            position: fixed;
            bottom: 40%;
            width: 96%;
            left: 7;
        }

        .modal-dialog {
            margin: 0 !important;
            padding: 0 !important;
        }
    }

    .page-item.active .page-link {
        background-color: #27313d !important;
        border-color: #27313d !important;
        color: #000;
    }

    .page-item .page-link {
        background-color: #151e27 !important;
        border-color: grey !important;
        color: grey !important;
    }

    .txn-history {
        text-align: left;
    }

    .txn-list {
        background-color: #1d2532;
        padding: 12px 10px;
        color: #777;
        font-size: 14px;
        margin: 7px 0;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 0, .16), 0 2px 10px 0 rgba(0, 0, 0, .12) !important;
        cursor: pointer;
    }

    .transaction-amount {
        float: right;
        color: #fff;
        font-weight: 800;
    }

    .transaction-number {
        float: right;
    }

    @media(max-width:991px) {
        #order_full_screen {
            display: none !important;
        }

        #order_small_screen {
            display: block !important;
        }
    }

    .transaction a {
        color: #808080 !important;
    }

    .transaction a.active {
        background-color: transparent !important;
        border-top: transparent;
        border-left: transparent;
        border-right: transparent;
        border-bottom: 2px solid #ffd700 !important;
        color: #ffd700 !important;
        font-weight: bold;
    }

    .transaction a:hover {
        border-bottom: 2px solid #ffd700 !important;
        border-top: 0px !important;
        border-left: 0px !important;
        border-right: 0px !important;
    }

    .alert-success {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
        border-radius: 0;
    }

    .alert-danger {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
        border-radius: 0;
    }

    .form-control {
        border-radius: 10px;
    }

    .form-control:focus {
        border: 1px solid #ffd700 !important;
    }
    </style>
</head>

<body class="hold-transition sidebar-mini layout-footer-fixed layout-fixed" style="background: #151e27;">
    <div id="preloader" class="loading" style="display: none"></div>
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand navbar-white"
            style="background: #151e27; border-bottom: 0; box-shadow: none!important;">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="index.php?<?php echo generate_string($permitted_chars, 100); ?>"
                        class="withanimation back_arrow"><i class="fas fa-angle-left pr-2"
                            style="font-size: 20px; color: #ffd700;"></i></a><span class="brand-text"
                        style="font-size: 20px;"><span
                            style="font-size: 20px; font-weight: bolder; line-height: 20px; color: #fff;">Payout
                            Request</span></a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </ul>
        </nav>

        <?php include ("navbar.php")?>
        <div class="content-wrapper">
            <div class="content-header p-0">
                <div class="container-fluid p-0">
                    <span id="message">
                        <?php echo $success_messages; ?>
                    </span>
                </div>
            </div>
            <section class="content">
                <div class="container-fluid pt-3">
                    <div class="card mt-3" style="border-radius: 10px; background-color: #1d2532; color: #fff;">
                        <nav>
                            <div class="nav nav-tabs transaction nav-fill" id="myTab" role="tablist">
                                <a class="nav-item nav-link active" href="#pending" data-toggle="tab" role="tab"
                                    aria-controls="nav-home" aria-selected="true">
                                    Pending
                                </a>
                                <a class="nav-item nav-link" href="#complete" data-toggle="tab" role="tab"
                                    aria-controls="nav-profile" aria-selected="false">
                                    Approved
                                </a>
                            </div>
                        </nav>
                        <div class="tab-content">
                            <div role="tablist" class="active tab-pane" id="pending">

                                <div class="card-body table-responsive p-3" id="order_full_screen">
                                    <table id="payout_table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Request ID</th>
                                                <th>Complete Name</th>
                                                <th>Amount Request</th>
                                                <th>Net Pay</th>
                                                <th width="20%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                        $sql_pending_req = "SELECT * FROM tbl_request_encashment WHERE status = 0";
                        $result_pending_req = $conn->query($sql_pending_req);
                          while($row_pending_req = mysqli_fetch_array($result_pending_req)) {
                            $user_id = $row_pending_req['unique_id'];

                            $requestingamount = $row_pending_req['amount']; //30600
                            $get10percent =  $requestingamount * 0.10; //3060
                            $less10percent =  $requestingamount - $get10percent; // 27540
                            $less20pesos =  $less10percent - 20;
                            $nettotalencashment = $less20pesos ;



                            $sql_user = "SELECT * FROM tbl_user_account WHERE unique_id = '$user_id'";
                            $result_user = $conn->query($sql_user);
                            $row_user = mysqli_fetch_assoc($result_user);
                      ?>
                                            <tr>
                                                <td style="color: #ffd700;">
                                                    <?php echo $row_pending_req['request_unique_code']; ?></td>
                                                <td><?php echo $row_user['firstname'].' '.$row_user['lastname']; ?></td>
                                                <td><span class="font-weight-bold text-warning">&#8369;
                                                        <?php echo number_format(($row_pending_req['amount'])); ?></span>
                                                </td>
                                                <td><span class="font-weight-bold text-warning">&#8369;
                                                        <?php echo number_format(($nettotalencashment)); ?></span></td>
                                                <td>
                                                    <a data-toggle="modal"
                                                        data-target="#approve<?php echo $row_pending_req['id']; ?>"
                                                        class="btn btn-sm btn-success">Approve</a>
                                                    <a data-toggle="modal"
                                                        data-target="#view_details<?php echo $row_pending_req['id']; ?>"
                                                        class="btn btn-sm btn-info">View Details</a>
                                                </td>
                                            </tr>

                                            <div class="modal" id="view_details<?php echo $row_pending_req['id']; ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content"
                                                        style="background-color: #151e27!important;">
                                                        <div class="modal-header pb-0" style="border: 0px;">
                                                            <h5 class="modal-title text-white"
                                                                style="font-weight: bold;">Other Details</h5>
                                                        </div>
                                                        <div class="modal-body pt-2 pb-0">
                                                            <div class="txn-history">
                                                                <p class="txn-list">
                                                                    <span class="text-white">Unique ID: </span><span
                                                                        class="transaction-amount"
                                                                        style="color: #ffd700;"><?php echo $row_pending_req['unique_id']; ?></span><br>
                                                                    <span class="text-white">Date Request: </span><span
                                                                        class="transaction-amount"
                                                                        style="color: #ffd700;"><?php echo date('F d Y', strtotime($row_pending_req['date_request'])); ?></span><br>
                                                                </p>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer" style="border: 0px">
                                                            <button type="button"
                                                                class="btn btn-default btn-lg btn-block"
                                                                style="background: transparent; color: #fff;"
                                                                data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="modal" id="approve<?php echo $row_pending_req['id']; ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content"
                                                        style="background-color: #151e27!important;">
                                                        <div class="modal-header pb-0" style="border: 0px;">
                                                            <h5 class="modal-title text-white"
                                                                style="font-weight: bold;">Approve Request</h5>
                                                        </div>
                                                        <div class="modal-body pt-0 pb-0">
                                                            <p class="text-muted">Are you sure you want to approve
                                                                request?</p>
                                                        </div>
                                                        <div class="modal-footer pr-0 pl-0 pb-2 pt-0"
                                                            style="display: block; border: 0px">
                                                            <div class="row">
                                                                <div class="col-6">
                                                                    <button type="button"
                                                                        class="btn btn-default btn-lg btn-block"
                                                                        style="background: transparent; color: #fff;"
                                                                        data-dismiss="modal">Cancel</button>
                                                                </div>
                                                                <div class="col-6">
                                                                    <form style="margin: 0;" method="POST">
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo $row_pending_req['id']; ?>">
                                                                        <input type="hidden" name="total_credit"
                                                                            value="<?php echo $row_pending_req['amount']; ?>">


                                                                        <input type="hidden" name="thenetpaid"
                                                                            value="<?php echo '$nettotalencashment'; ?>">



                                                                        <input type="hidden" name="unique_id"
                                                                            value="<?php echo $row_pending_req['unique_id'] ?>">
                                                                        <button type="submit" name="approve"
                                                                            class="btn btn-warning btn-lg btn-block withanimation_submit"
                                                                            style="background: #FFD700; border-color: #ffd700;">Yes,
                                                                            Submit</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>

                                <span id="order_small_screen" style="display:none;">
                                    <?php 
                    $sql_pending_req = "SELECT * FROM tbl_request_encashment WHERE status = 0";
                      $result_pending_req = $conn->query($sql_pending_req);
                      if($result_pending_req->num_rows > 0) {
                  ?>
                                    <div class="input-group mb-3 mt-3 ml-2">
                                        <div class="input-group-prepend">
                                            <button class="btn bg-white"
                                                style="border-top-left-radius: 10px; border-bottom-left-radius: 10px;"
                                                type="submit" name="search"><i class="fas fa-search"></i></button>
                                        </div>
                                        <input type="text" class="form-control border-left-0 mr-3" id="code_search"
                                            placeholder="Search Request number..." required />
                                    </div>
                                    <?php } ?>
                                    <span id="search_result">
                                        <?php 
                          $sql_code_s = "SELECT * FROM tbl_request_encashment WHERE status = 0";
                          $result_code_s = $conn->query($sql_code_s);
                          if ($result_code_s->num_rows > 0) {
                            while($row_code_s = mysqli_fetch_array($result_code_s)) {
                              $user_id = $row_code_s['unique_id'];
                              $requestingamount = $row_code_s['amount']; //30600
                              $get10percent =  $requestingamount * 0.10; //3060
                              $less10percent =  $requestingamount - $get10percent; // 27540
                              $less20pesos =  $less10percent - 20;
                              $nettotalencashment = $less20pesos ;

                              $sql_user = "SELECT * FROM tbl_user_account WHERE unique_id = '$user_id'";
                              $result_user = $conn->query($sql_user);
                              $row_user = mysqli_fetch_assoc($result_user);
                      ?>
                                        <a data-toggle="modal"
                                            data-target="#approve_small<?php echo $row_code_s['id']; ?>">
                                            <div class="txn-history ml-2 mr-2">
                                                <p class="txn-list">
                                                    <span class="text-white">Request ID: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo $row_code_s['request_unique_code']; ?></span><br>
                                                    <span class="text-white">Completename: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo $row_user['firstname'].' '.$row_user['lastname']; ?></span><br>
                                                    <span class="text-white">Amount: </span><span
                                                        class="transaction-amount" style="color: #ffd700;">&#8369;
                                                        <?php echo number_format(($row_code_s['amount'])); ?></span><br>
                                                    <span class="text-white">Net Pay: </span><span
                                                        class="transaction-amount" style="color: #ffd700;">&#8369;
                                                        <?php echo number_format(($nettotalencashment)); ?></span><br>
                                                    <span class="text-white">Date Request: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo date('F d Y', strtotime($row_code_s['date_request'])); ?></span>
                                                </p>
                                            </div>
                                        </a>

                                        <div class="modal" id="approve_small<?php echo $row_code_s['id']; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content" style="background-color: #151e27!important;">
                                                    <div class="modal-header pb-0" style="border: 0px;">
                                                        <h5 class="modal-title text-white" style="font-weight: bold;">
                                                            Approve Request</h5>
                                                    </div>
                                                    <div class="modal-body pt-0 pb-0">
                                                        <p class="text-muted">Are you sure you want to approve request?
                                                        </p>
                                                    </div>
                                                    <div class="modal-footer pr-0 pl-0 pb-2 pt-0"
                                                        style="display: block; border: 0px">
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <button type="button"
                                                                    class="btn btn-default btn-lg btn-block"
                                                                    style="background: transparent; color: #fff;"
                                                                    data-dismiss="modal">Cancel</button>
                                                            </div>
                                                            <div class="col-6">
                                                                <form style="margin: 0;" method="POST">
                                                                    <input type="hidden" name="id"
                                                                        value="<?php echo $row_code_s['id']; ?>">
                                                                    <input type="hidden" name="total_credit"
                                                                        value="<?php echo $row_code_s['amount']; ?>">

                                                                    <input type="hidden" name="thenetpaid"
                                                                        value="<?php echo '$nettotalencashment'; ?>">

                                                                    <input type="hidden" name="unique_id"
                                                                        value="<?php echo $row_code_s['unique_id'] ?>">
                                                                    <button type="submit" name="approve"
                                                                        class="btn btn-warning btn-lg btn-block withanimation_submit"
                                                                        style="background: #FFD700; border-color: #ffd700;">Yes,
                                                                        Submit</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php } }else{ ?>
                                        <center>
                                            <div class="text-center error-content p-3">
                                                <i class="fas fa-box-open text-warning"
                                                    style="margin-top: 30px; margin-bottom: 10px; font-size: 80px;"></i>
                                                <h6 class="font-weight-bold text-white"> No Request.</h6>
                                                <br><br>
                                            </div>
                                        </center>
                                        <?php } ?>
                                    </span>
                                </span>

                            </div> <!-- pending -->

                            <div role="tablist" class="tab-pane" id="complete">
                                <div class="card-body table-responsive p-3" id="order_full_screen">
                                    <table id="approve_table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Request ID</th>
                                                <th>Complete Name</th>
                                                <th>Amount Requested</th>
                                                <th>Net Pay</th>
                                                <th width="20%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                        $sql_pending_req = "SELECT * FROM tbl_request_encashment WHERE status = 1";
                        $result_pending_req = $conn->query($sql_pending_req);
                          while($row_pending_req = mysqli_fetch_array($result_pending_req)) {
                            $user_id = $row_pending_req['unique_id'];
                            $requestingamount = $row_pending_req['amount']; //30600
                            $get10percent =  $requestingamount * 0.10; //3060
                            $less10percent =  $requestingamount - $get10percent; // 27540
                            $less20pesos =  $less10percent - 20;
                            $nettotalencashment = $less20pesos ;


                            $sql_user = "SELECT * FROM tbl_user_account WHERE unique_id = '$user_id'";
                            $result_user = $conn->query($sql_user);
                            $row_user = mysqli_fetch_assoc($result_user);
                      ?>
                                            <tr>
                                                <td style="color: #ffd700;">
                                                    <?php echo $row_pending_req['request_unique_code']; ?></td>
                                                <td><?php echo $row_user['firstname'].' '.$row_user['lastname']; ?></td>
                                                <td><span class="font-weight-bold text-warning">&#8369;
                                                        <?php echo number_format(($row_pending_req['amount'])); ?></span>
                                                </td>
                                                <td><span class="font-weight-bold text-warning">&#8369;
                                                        <?php echo number_format(($nettotalencashment)); ?></span>
                                                </td>
                                                <td>
                                                    <a data-toggle="modal"
                                                        data-target="#view_details<?php echo $row_pending_req['id']; ?>"
                                                        class="btn btn-sm btn-info">View Details</a>
                                                </td>
                                            </tr>

                                            <div class="modal" id="view_details<?php echo $row_pending_req['id']; ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content"
                                                        style="background-color: #151e27!important;">
                                                        <div class="modal-header pb-0" style="border: 0px;">
                                                            <h5 class="modal-title text-white"
                                                                style="font-weight: bold;">Other Details</h5>
                                                        </div>
                                                        <div class="modal-body pt-2 pb-0">
                                                            <div class="txn-history">
                                                                <p class="txn-list">
                                                                    <span class="text-white">Unique ID: </span><span
                                                                        class="transaction-amount"
                                                                        style="color: #ffd700;"><?php echo $row_pending_req['unique_id']; ?></span><br>
                                                                    <span class="text-white">Date Request: </span><span
                                                                        class="transaction-amount"
                                                                        style="color: #ffd700;"><?php echo date('F d Y', strtotime($row_pending_req['date_request'])); ?></span><br>
                                                                    <span class="text-white">Date Request: </span><span
                                                                        class="transaction-amount"
                                                                        style="color: #ffd700;"><?php echo date('F d Y', strtotime($row_pending_req['date_approve'])); ?></span><br>
                                                                </p>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer" style="border: 0px">
                                                            <button type="button"
                                                                class="btn btn-default btn-lg btn-block"
                                                                style="background: transparent; color: #fff;"
                                                                data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>

                                <span id="order_small_screen" style="display:none;">
                                    <?php 
                    $sql_pending_req = "SELECT * FROM tbl_request_encashment WHERE status = 1";
                      $result_pending_req = $conn->query($sql_pending_req);
                      if($result_pending_req->num_rows > 0) {
                  ?>
                                    <div class="input-group mb-3 mt-3 ml-2">
                                        <div class="input-group-prepend">
                                            <button class="btn bg-white"
                                                style="border-top-left-radius: 10px; border-bottom-left-radius: 10px;"
                                                type="submit" name="search"><i class="fas fa-search"></i></button>
                                        </div>
                                        <input type="text" class="form-control border-left-0 mr-3" id="approve_search"
                                            placeholder="Search Request number..." required />
                                    </div>
                                    <?php } ?>
                                    <span id="approve_result">
                                        <?php 
                          $sql_code_s = "SELECT * FROM tbl_request_encashment WHERE status = 1";
                          $result_code_s = $conn->query($sql_code_s);
                          if ($result_code_s->num_rows > 0) {
                            while($row_code_s = mysqli_fetch_array($result_code_s)) {
                              $user_id = $row_code_s['unique_id'];

                              $sql_user = "SELECT * FROM tbl_user_account WHERE unique_id = '$user_id'";
                              $result_user = $conn->query($sql_user);
                              $row_user = mysqli_fetch_assoc($result_user);
                      ?>
                                        <a data-toggle="modal"
                                            data-target="#approve_small<?php echo $row_code_s['id']; ?>">
                                            <div class="txn-history ml-2 mr-2">
                                                <p class="txn-list">
                                                    <span class="text-white">Request ID: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo $row_code_s['request_unique_code']; ?></span><br>
                                                    <span class="text-white">Completename: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo $row_user['firstname'].' '.$row_user['lastname']; ?></span><br>
                                                    <span class="text-white">Amount: </span><span
                                                        class="transaction-amount" style="color: #ffd700;">&#8369;
                                                        <?php echo number_format(($row_code_s['amount'])); ?></span><br>
                                                    <span class="text-white">Date Request: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo date('F d Y', strtotime($row_code_s['date_request'])); ?></span><br>
                                                    <span class="text-white">Date Approve: </span><span
                                                        class="transaction-amount"
                                                        style="color: #ffd700;"><?php echo date('F d Y', strtotime($row_code_s['date_approve'])); ?></span>
                                                </p>
                                            </div>
                                        </a>

                                        <?php } }else{ ?>
                                        <center>
                                            <div class="text-center error-content p-3">
                                                <i class="fas fa-box-open text-warning"
                                                    style="margin-top: 30px; margin-bottom: 10px; font-size: 80px;"></i>
                                                <h6 class="font-weight-bold text-white"> No Request.</h6>
                                                <br><br>
                                            </div>
                                        </center>
                                        <?php } ?>
                                    </span>
                                </span>

                            </div> <!-- approve -->

                        </div> <!-- tab-content -->
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script src="dist/js/adminlte.min.js"></script>
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="plugins/jquery-validation/additional-methods.min.js"></script>
    <script src="dist/js/pages/dashboard.js"></script>
    <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
            localStorage.setItem('activeTab', $(e.target).attr('href'));
        });
        var activeTab = localStorage.getItem('activeTab');
        if (activeTab) {
            $('#myTab a[href="' + activeTab + '"]').tab('show');
        }

        $('#code_search').keyup(function() {
            var pending_request = $(this).val();
            var btn_action = "pending_search";
            $.ajax({
                url: 'fetch_data.php',
                method: "POST",
                dataType: "html",
                data: {
                    pending_request: pending_request,
                    btn_action: btn_action
                },
                success: function(data) {
                    $('#search_result').html(data);
                }
            });
        });

        $('#approve_search').keyup(function() {
            var approve_request = $(this).val();
            var btn_action = "approve_search";
            $.ajax({
                url: 'fetch_data.php',
                method: "POST",
                dataType: "html",
                data: {
                    approve_request: approve_request,
                    btn_action: btn_action
                },
                success: function(data) {
                    $('#approve_result').html(data);
                }
            });
        });

    });
    $(function() {
        $("#payout_table").DataTable({
            "responsive": true,
            "autoWidth": false,
        });
        $("#approve_table").DataTable({
            "responsive": true,
            "autoWidth": false,
        });
        $(".withanimation_submit").click(function() {
            $(".loading").show();
        });
        $(".withanimation").click(function(e) {
            e.preventDefault();
            $(".loading").show();
            var url = $(this).attr("href");
            setTimeout(function() {
                window.location = url;
            }, 500);
        });
    });
    setTimeout(function() {
        $('#message').html('');
    }, 5000);

    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
</body>

</html>
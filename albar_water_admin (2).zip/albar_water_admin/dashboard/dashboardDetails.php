

<section class="content bg-white pt-3 pb-2 mt-2">
  <div class="container-fluid">
    <div class="row maxBars">
      <div class="col-md-3">
        <a href="all_members_filter.php" class="click-link">
            <div class="info-box card-transaction btn-radius" 
            style="background-image: linear-gradient(to right, #5a2568, #740000)">
              <span class="info-box-icon text-white"><i class="fas fa-users"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-white" style="letter-spacing: 2;">MEMBERS</span>
                <span class="info-box-number">
                  <b style="color: #fff;font-size: 20px;"> 
                  <?php  $result = mysqli_query($conn , "SELECT * FROM tbl_user_account");
          $total= mysqli_num_rows($result);
          echo mysqli_num_rows($result); ?> </b> 
                </span>
              </span>
            </div>
            <i class="fas fa-angle-right mr-2 mt-4 text-white"></i>
          </div>
        </a>
      </div>
 
      <div class="col-md-3">
        <a href="indexpaymentrecords.php?filter_date=all" class="click-link">
       
           <div class="info-box card-transaction btn-radius" style="background-image: linear-gradient(to right, #051f5a, #051f5a);">
            <span class="info-box-icon text-white"><i class="fas  fa-money-bill"></i></span>
            <div class="info-box-content">
              <span class="info-box-text text-white" style="letter-spacing: 2;">Payment Summary</span>
              <span class="info-box-number text-white">    
                <b style="color: #fff;font-size: 20px;"> </b> 
              </span> 
            </div>
            <i class="fas fa-angle-right mr-2 mt-4 text-white"></i>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a href="#" class="click-link">
       
           <div class="info-box card-transaction btn-radius" 
           style="background-image: linear-gradient(to right, #055a2c, #207111);">
            <span class="info-box-icon text-white"><i class="fas  fa-money-bill"></i></span>
            <div class="info-box-content">
              <span class="info-box-text text-white" style="letter-spacing: 2;">Meter Device Pending Collection</span>
              <span class="info-box-number text-white">    
                <b style="color: #fff;font-size: 20px;"><?php  
     
          ?>0</b> 
              </span> 
            </div>
            <i class="fas fa-angle-right mr-2 mt-4 text-white"></i>
          </div>
        </a>
      </div>


            <div class="col-md-3">
        <a href="indexpaymentrecords.php?filter_date=all" class="click-link">
       
           <div class="info-box card-transaction btn-radius" style="background-image: linear-gradient(to right, #051f5a, #051f5a);">
            <span class="info-box-icon text-white"><i class="fas  fa-money-bill"></i></span>
            <div class="info-box-content">
              <span class="info-box-text text-white" style="letter-spacing: 2;">Today Payment Received.</span>
              <span class="info-box-number text-white">    
                <b style="color: #fff;font-size: 20px;"><?php  

                if ($todaypayreceived > 0) {
                  echo '&#8369;'.$todaypayreceived;
                }else {
                  echo '&#8369; 0.00';
                }
     
          ?></b> 
              </span> 
            </div>
            <i class="fas fa-angle-right mr-2 mt-4 text-white"></i>
          </div>
        </a>
      </div>
 
    </div> <!-- end row -->

    <a href="sortreadings.php" class="btn btn-danger"  ><i class="fas fa-user-plus"></i> <span>Sort Reading </span></a>
  
    <a href="#" class="btn btn-warning" data-target="#others"  data-toggle="modal"><i class="fas fa-user-plus"></i> <span>Reports </span></a>
  
    <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="fas fa-user-plus"></i> <span>Add New </span></a>
 
    <a href="#select_reading" type="button"  data-toggle="modal" data-target="#select_reading"  class="btn btn-outline-danger btn-radius" > <?php
       $sql_checkplacement = "SELECT *   FROM tbl_reading_sched where status = 1 ";
          $result_countplacement = mysqli_query($conn, $sql_checkplacement);
          $row_date = mysqli_fetch_assoc($result_countplacement);

          $c_readingdate =  $row_date ["reading_date"];
          $c_due_date =  $row_date ["due_date"];
          $c_disconnection_date=  $row_date ["disconnection_date"];

          echo '<center> <b> <i class="fas fa-circle-notch"></i> Reading Date: </b>'.$c_readingdate;
          echo '| <b>Due Date: </b>'.$c_due_date;
          echo '| <b>Disconnection Date: </b>'.$c_disconnection_date.'</center>';
?> </a>



</section>


	<!-- Add Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form">
					<div class="modal-header">						
						<h4 class="modal-title">Add New Member</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>Acct Number</label>
							<input type="text" id="acctnumber" name="acctnumber" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Account Holder Name/s</label>
							<input type="email" id="accntholder" name="accntholder" class="form-control" required>
						</div>
						<div class="form-group">
							<label>First Name</label>
							<input type="phone" id="fname" name="fname" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Last Name</label>
							<input type="city" id="lname" name="lname" class="form-control" required>
						</div>		
            <div class="form-group">
							<label>Home Address</label>
							<input type="city" id="address" name="address" class="form-control" required>
						</div>			
					</div>
					<div class="modal-footer">
					    <input type="hidden" value="1" name="type">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<button type="button" class="btn btn-success" id="btn-add">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>





<div class="modal" id="select_reading">
    <div class="modal-dialog">
     <div class="modal-content btn-radius">
       <div class="modal-body pt-0 pb-0">
          <div class="col-12">

                <form method="POST" action="" class="form-horizontal" id="quickForm" enctype="multipart/form-data">
                <br>
              
              
              <label for="datepost">Select Reading Date:</label>
              <select   class="form-control" name="select_readingdate"  aria-label="Default select example">
              <option value="" disabled>Select Date</option>
              <?php    if (!isset($_GET['dat']))
                   {
                        $result = mysqli_query($conn , "SELECT * FROM tbl_reading_sched order by  id desc");
                   }
                    $cnt = 0 ;
                    while( $row = mysqli_fetch_array($result) )
                    {
                        $cnt++;

                        ?>
                       
                         <option value="<?php echo $row['reading_date'] ?>"><?php echo $row['reading_date']  ?></option>
                <?php } ?>
             </select>

 
             <!--    <option value="<?= $value?>"><?= $value?></option>-->
             
             <br>


                      <input type="hidden" name="save_data_1" value="save">
                      <button type="submit" id="action" class="btn btn-warning btn-save btn-block">
                        <span id="button-text">Update</span>
                      </button>
        </form> 
                      <br>
      </div> 
  </div>
  </div>  
  </div> 
  </div> 


 




 
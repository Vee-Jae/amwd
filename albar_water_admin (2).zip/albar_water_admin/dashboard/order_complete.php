            <div class="card mt-3" style="border-radius: 10px; background-color: #1d2532; color: #fff;" id="order_full_screen">
              <div class="card-body table-responsive p-3">
                  <table id="complete_table" class="table table-hover">
                    <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer</th>
                      <th>Customer Details</th>
                      <th>Date</th>
                      <th width="17%">Action</th>
                    </tr>
                    </thead>
                    <tbody id="pending_tbody">
                    <?php 
                      $sql_order = "SELECT * FROM tbl_user_checkout WHERE order_status = '4'";
                      $result_order = $conn->query($sql_order);
                        while($row_order = mysqli_fetch_array($result_order)) {
                          $ordernumber = $row_order['order_number'];
                    ?>
                    <tr>
                      <td><?php echo $row_order['order_number']; ?></td>
                      <td><?php echo $row_order['completename']; ?></td>
                      <td>
                        <?php echo $row_order['contactnumber']; ?><br>
                        <?php echo $row_order['complete_address']; ?>
                      </td>
                      <td><?php echo date('F d Y', strtotime($row_order['date_checkout'])); ?></td>
                      <td>
                        <a data-toggle="modal" data-target="#order<?php echo $row_order['id']; ?>" class="btn btn-sm btn-info">View Order</a>
                      </td>
                    </tr>

                    <div class="modal" id="order<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Order Details</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0">
                            <div style="display: flex; justify-content: space-between;">
                              <span class="text-white">Total:</span>
                              <span class="text-white" style="font-size: 20px; font-weight: bolder;">&#8369; <?php echo number_format(($row_order['order_total'])) ?>.00</span>
                            </div>
                            <?php 
                                $sql_cart = "SELECT * FROM tbl_user_checkout_details WHERE order_number = '$ordernumber'";
                                $result_cart = $conn->query($sql_cart);
                                  while($row_cart = mysqli_fetch_array($result_cart)) {
                                  $product_id = $row_cart['product_id'];
                                    $sql_product_details = "SELECT * FROM tbl_product WHERE product_id = '$product_id'";
                                    $result_product_details = mysqli_query($conn, $sql_product_details);
                                    $row_product_details = mysqli_fetch_assoc($result_product_details);
                            ?>
                            <div class="txn-history">
                              <p class="txn-list">
                                <span class="text-white">QTY: <b><?php echo $row_cart['quantity']; ?>x</b></span>
                                <span class="transaction-amount"><span class="text-white">Item: <b><?php echo $row_product_details['product_name']; ?></span>
                              </p>
                            </div>
                            <?php } ?>
                          </div>
                          <div class="modal-footer" style="border: 0px">
                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>
            

            <div id="order_small_screen" style="display: none;">
            <?php
              $sql_order = "SELECT * FROM tbl_user_checkout WHERE order_status = '4'";
              $result_order = $conn->query($sql_order);
              if ($result_order->num_rows > 0) { ?>
                <div class="input-group mb-3 mt-3">
                  <div class="input-group-prepend">
                    <button class="btn bg-white" style="border-top-left-radius: 10px; border-bottom-left-radius: 10px;" type="submit" name="search"><i class="fas fa-search" ></i></button>
                  </div>
                  <input type="text" class="form-control border-left-0" id="complete_search" placeholder="Search Order number..." required/>
                </div>
            <?php } ?>

            <span id="complete_result">  
            <?php
              $sql_order = "SELECT * FROM tbl_user_checkout WHERE order_status = '4'";
              $result_order = $conn->query($sql_order);
              if ($result_order->num_rows > 0) {
                while($row_order = mysqli_fetch_array($result_order)) {
                  $ordernumber = $row_order['order_number'];
            ?>
              <a data-toggle="modal" data-target="#order_small<?php echo $row_order['id']; ?>">
                <div class="txn-history">
                  <p class="txn-list">
                    <span class="text-white">Order ID: </span><span class="transaction-amount" style="color: #ffd700;"><?php echo $row_order['order_number']; ?></span><br>
                    <span class="text-white">Customer: </span><span class="transaction-amount"><?php echo $row_order['completename']; ?></span><br>
                    <span class="text-white">Mobile Number: </span><span class="transaction-amount"><?php echo $row_order['contactnumber']; ?></span><br>
                    <span class="text-white">Address: </span><span class="transaction-amount"><?php echo $row_order['complete_address']; ?></span><br>
                  </p>
                </div>
              </a> 

                    <div class="modal" id="order_small<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Order Details</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0">
                            <div style="display: flex; justify-content: space-between;">
                              <span class="text-white">Total:</span>
                              <span class="text-white" style="font-size: 20px; font-weight: bolder;">&#8369; <?php echo number_format(($row_order['order_total'])) ?>.00</span>
                            </div>
                            <?php 
                                $sql_cart = "SELECT * FROM tbl_user_checkout_details WHERE order_number = '$ordernumber'";
                                $result_cart = $conn->query($sql_cart);
                                  while($row_cart = mysqli_fetch_array($result_cart)) {
                                  $product_id = $row_cart['product_id'];
                                    $sql_product_details = "SELECT * FROM tbl_product WHERE product_id = '$product_id'";
                                    $result_product_details = mysqli_query($conn, $sql_product_details);
                                    $row_product_details = mysqli_fetch_assoc($result_product_details);
                            ?>
                            <div class="txn-history">
                              <p class="txn-list">
                                <span class="text-white">QTY: <b><?php echo $row_cart['quantity']; ?>x</b></span>
                                <span class="transaction-amount"><span class="text-white">Item: <b><?php echo $row_product_details['product_name']; ?></span>
                              </p>
                            </div>
                            <?php } ?>
                          </div>
                          <div class="modal-footer" style="border: 0px">
                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
  
        <?php } }else{ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-box-open text-warning" style="margin-top: 100px; margin-bottom: 10px; font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> No Complete Order.</h6>
            </div>
          </center>
        <?php } ?>
         </span>
      </div>


<script type="text/javascript">
$(document).ready(function () {
  $('#complete_search').keyup(function() {
    var complete = $(this).val();
    var btn_action = "complete_search";
     $.ajax({
      url:'search_order.php',
      method:"POST",
      dataType:"html",
      data:{complete:complete, btn_action:btn_action},
      success:function(data){
        $('#complete_result').html(data);
      }
    });
  });
});
  $(function () {
    $("#complete_table").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
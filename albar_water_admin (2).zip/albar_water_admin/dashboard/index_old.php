<?php
 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 $datetoday = date('d F Y, h:i A'); 

 $active_tab = "dashboard"; 

 if (isset($_POST['save_data'])) {
  
 $readingdate = $_POST ['reading'];
 $duedate = $_POST ['due'];
 $disconnectiondate = $_POST ['disconnection'];

  $update_reading= "UPDATE tbl_reading_sched SET reading_date = '$readingdate',due_date = '$duedate',disconnection_date = '$disconnectiondate'  WHERE status = 1";
  mysqli_query($conn, $update_reading);
   
      $success = '<span class="text-success"><b>Successfully Upgraded!</b></span>';
  
 
 }


 if (isset($_POST['save_data_1'])) {
  
  $select_readingdate = $_POST ['select_readingdate']; 


  $update_reading= "UPDATE tbl_reading_sched SET status = 0";
  mysqli_query($conn, $update_reading);



   $update_reading= "UPDATE tbl_reading_sched SET status = 1  WHERE  reading_date = '$select_readingdate' ";
   mysqli_query($conn, $update_reading);
    
       $success = '<span class="text-success"><b>Successfully updated!</b></span>';
   
  
  }

 
  
  ?> 
  
  
<!DOCTYPE html>
<html>
<head>
  <title>AWS Admin  Dashboard</title>
  <?php include_once('linkStyle.php'); ?>
  
 
</head>
<body class="hold-transition   layout-footer-fixed layout-fixed sidebar-collapse">

<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="index.js"></script>


<div id="preloader" style="display:none;"></div>
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
   
      <li class="nav-item ml-2">
        <span class="brand-text title-form-brand font-weight-bolder fontSize-20">Dashboard</span>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item minBars">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item dropdown" id="dropDownFullScreen">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fas fa-user"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <i class="fas fa-user mr-2"></i> 
            <span class="text-muted text-sm">Profile</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="../logout.php" class="dropdown-item dropdown-footer">Logout</a>
        </div>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
  <?php include_once('navbar.php'); ?>

  <div class="content-wrapper">
  <?php  
   
  include_once('referral_link.php');  
  
  include_once('dashboardDetails.php');  
 echo '<br>';
      include_once('all_members.php'); 
  ?>
  </div>

   
  
  <aside class="control-sidebar control-sidebar-dark">
  </aside>
</div>
<!-- ./wrapper -->
 

<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
 
<!-- page script -->
<script>

function copyFunc() {
  var copyText = document.getElementById("copyInp");
  copyText.select();
  document.execCommand("copy"); //this function copies the text of the input with ID "copyInp"
}


  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
 
  
 
</script>



</body>
</html>


<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});
</script>
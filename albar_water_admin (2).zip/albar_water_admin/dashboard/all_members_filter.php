<?php
 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 
 if (!isset($_SESSION['username'])) { ?>
  <script language="javascript">
    window.location.href = '../index.php';
  </script>
<?php }


 $datetoday = date('Y-m-d'); 

 $active_tab = "dashboard"; 

 if (isset($_POST['save_data'])) {
  
 $select_opt = $_POST ['select_opt'];
 

  
 
 }


 

 
?>


<!DOCTYPE html>
<html>
<head>
  <title>AWS Admin  Dashboard</title>

 
</head>
<body class="hold-transition   layout-footer-fixed layout-fixed sidebar-collapse">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
 
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-colvis-1.6.1/b-html5-1.6.1/b-print-1.6.1/r-2.2.3/datatables.min.css" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-colvis-1.6.1/b-html5-1.6.1/b-print-1.6.1/r-2.2.3/datatables.min.js"></script>


  <?php include_once('linkStyle.php'); ?>
  
<style>
  .currencyinput {
    border: 1px inset #ccc;
}
.currencyinput input {
    border: 0;
}
  </style>
<div id="preloader" style="display:none;"></div>
<div class="wrapper">
 

<section class="content-header bg-primary">
      <div class="container-fluid">
        <div class="display-flex-item">
          <div>
          <center>   <div class="fontSize-22 font-weight-bolder text-light">
            (
              
          
              <?php 
            
            if ($totalcollection == NULL) {
              echo '&#8369;0.00' ;
            }else {

            echo '&#8369;'.number_format(($totalcollection)) ;
            }
            ?>)
            <br>
            Total Collection </div>
           
            
             
              </b> 
              </div> 
            </div>
            <div style="line-height: 45px;text-align:center;">
            
         
            <!-- <a href="resetall.php" class="btn btn-outline-success btn-radius click-link" style="
    background-color: #28a745;
    color: #fff;
"><b>Reset All</b></a> -->
          </div></center> 
 
          </div>
     </section>


  <!-- /.navbar -->
  <?php include_once('navbar.php'); ?>

  <div class="content-wrapper">

  <?php  
  
 include_once('all_membersdata.php'); 
  ?>
    
  <br>
  <?php include_once('footer.php'); ?>
  <aside class="control-sidebar control-sidebar-dark">
  </aside>
</div>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>


  
  
<script src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>

<script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.bootstrap4.min.js"></script>
 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.colVis.min.js"></script>

 
 
<!-- page script -->
<script>
 


$(function () {
  
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
 
 


        $(document).ready(function() {
    $('#example1').DataTable( {
      "responsive": true,
      "autoWidth": false,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
  
 
</script>

<script type="text/javascript"> 

//add meter reading
$(document).on("click", ".addmeterreading", function (e) {
  var id1 = $(this).attr("data-id");
  var acctholder1 = $(this).attr("data-name");
  var prevreading = $(this).attr("data-prevreading");

  $("#id_u1").val(id1);
  $("#txt_acct_holder1").val(acctholder1);
  $("#id-1").val(prevreading);
 
});

 

$(function () {
  $("#id-1, #id-2, #id-3,#id-4,#id-5").keyup(function () {
      (+$("#id-3").val
    (+$("#id-2").val() - +$("#id-1").val())) ;
  
    (+$("#id-5").val
    (+$("#id-3").val() * +$("#id-4").val())) ;

  });
});
</script>


</body>
</html>
	<script src="index_3.js"></script>
  
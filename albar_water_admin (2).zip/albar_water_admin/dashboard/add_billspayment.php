
	<!-- Add Payment TAB HTML -->
	<div id="addPaymentModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form_billspayment">

				 <div class="modal-header">						
						<h4 class="modal-title">Add Payment Details</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body">	
					<div class="row">
									<div class="col-sm-3">
										<label for="datepost">Account#: </label>
										<input type="text" id="id_u" name="id" class="form-control" readonly>	
									</div>
								<div class="col-sm-9">
										<label for="datepost">Account Holder: </label>
										<input type="text" id="txt_acct_holder" name="acctholder"  class="form-control" readonly>	
								</div>
					 </div>
				 <br>
									<div class="card card-primary card-outline card-tabs">
										<div class="card-header p-0 pt-1 border-bottom-0">
											<ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
											<li class="nav-item">
												<a class="nav-link active" id="custom-tabs-three-home-tab" data-toggle="pill" href="#custom-tabs-three-waterbill" role="tab" aria-controls="custom-tabs-three-home" aria-selected="true">Water Bill</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" id="custom-tabs-three-profile-tab" data-toggle="pill" href="#custom-tabs-three-meterdevice" role="tab" aria-controls="custom-tabs-three-profile" aria-selected="false">Meter Device</a>
											</li>
										<!--	<li class="nav-item">
												<a class="nav-link" id="custom-tabs-four-messages-tab" data-toggle="pill" href="#custom-tabs-three-otherpurchase" role="tab" aria-controls="custom-tabs-three-messages" aria-selected="false">Other Purchase</a>
											</li> -->

										
											
											</ul>
										</div>
									</div>

			  
              <div >
                <div class="tab-content " id="custom-tabs-three-tabContent">
                  <div class="tab-pane fade show active" id="custom-tabs-three-waterbill" role="tabpanel" aria-labelledby="custom-tabs-three-home-tab">  <CENTER style="background: #2f2f2f;color: #fff;font-size: 20px;"> <b style color="#e90707;">PAY WATER BILL</b> </CENTER>
				<hr>
											<div class="form-group">
											<label for="datepost">Select Reading Date: </label>
										<select   class="form-control" name="select_readingdate"  aria-label="Default select example">
										<option value="" disabled>Select Date</option>
										<?php    if (!isset($_GET['dat']))
											{
													$result = mysqli_query($conn , "SELECT * FROM tbl_reading_sched   order by  status desc");
											}
												$cnt = 0 ;
												while( $row = mysqli_fetch_array($result) )
												{
													$cnt++;

													?>
												
													<option value="<?php echo $row['reading_date']; ?>">
													<?php 
													echo $row['reading_date']; 
											?></option>
											<?php } ?>
										</select>
										</div>
			 

		
						


										<div class="form-group">
										<label for="datepost">Payment Collection Date:</label>
										<?php if (($_SESSION['username'] == 'MainAdmin')) { ?>
											<input type="date" value="<?php echo $thedatetoday; ?>" class="form-control"  id="reading" name="payment_date">
										<?php }else {?>
										
											<input type="date" value="<?php echo $thedatetoday; ?>" class="form-control"  id="reading" name="payment_date" readonly>
										
											<?php }?>

										</div>
										<div class="form-group" style="
											background: #f80000;
											padding: 10px;
											color: #fff;
										">
									<label>Unpaid Balance:</label>
									<input type="text" id="meterbalance" name="meterbalance"  class="form-control" style="
										font-size: 18px;
										color: red;
										font-weight: bold;
									" readonly>	 <hr>
									<input type="text" id="wbbalance" name="wbbalance"  class="form-control" style="
										font-size: 18px;
										color: blue;
										font-weight: bold;
									" readonly>	 
									
								
								</div>


									<div class="form-group">
									<label>Enter Amount:</label>
										<input type="number" name="waterbill_amount" min="0" placeholder="0" class="form-control" style="
										font-size: 40px;
										color: #ff0505;
										padding: 10px;
										font-weight: bold;
										text-align: center;
									" required autofocus>
									</div>
							
								 
									<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="modeofpay" id="inlineRadio1" value="CASH" checked >
									<label class="form-check-label" for="inlineRadio1"><b>CASH</b></label>
									</div>
									<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="modeofpay" id="inlineRadio2" value="GCASH">
									<label class="form-check-label" for="inlineRadio2"><b>G-CASH</b></label>
									 </div>
									 
						 
               
 						
							<div class="modal-footer">
								<input type="hidden" value="5" name="type">
								<button type="button" class="btn btn-success btn-radius btn-block btn-multi text-white" id="btn-addbillspayment">Submit Payment</button>
							</div>

				
				</form>
				 

				
							<!--end BILL PAYMENT TAB--> 
							<center><a href="transactionhistory.php?mid=" onclick="this.href = this.href + document.getElementById('id_u').value;">[View Payment History]</a> </center>
				</div>
				 
				
			 
              			 <div class="tab-pane fade" id="custom-tabs-three-meterdevice" role="tabpanel" aria-labelledby="custom-tabs-three-profile-tab">
             				  <CENTER> <b style color="#e90707;">PAY METER DEVICE</b> </CENTER>
											
										<form id="user_form_meterdevicepayment">
												<label for="datepost">Account#: </label>
												<input type="text" id="id_u2" name="id" class="form-control" readonly>	
									
																	<div class="form-group">
																		<label for="datepost">Payment Date:</label>
																		<?php if (($_SESSION['username'] == 'MainAdmin')) { ?>
																			
																			<input type="date" class="form-control"  id="reading" name="payment_date">
																			<?php }else { ?>

																				<input type="text" value=<?php echo $thedatetoday;?> class="form-control"  id="reading" name="payment_date" readonly>

																				<?php } ?>
																		</div>

																		<div class="form-group">
																		<label>Enter Amount:</label>
																			<input type="number" name="waterbill_amount" min="0" placeholder="0" class="form-control" style="
																			font-size: 40px;
																			color: #ff0505;
																			padding: 10px;
																			font-weight: bold;
																			text-align: center;
																		" required>
																		</div>
												
																		<label>Mode of Payment:</label>
																					<div class="form-check form-check-inline">
																						<input class="form-check-input" type="radio" name="modeofpay" id="inlineRadio1" value="CASH">
																						<label class="form-check-label" for="inlineRadio1"><b>CASH</b></label>
																					</div>
																					<div class="form-check form-check-inline">
																						<input class="form-check-input" type="radio" name="modeofpay" id="inlineRadio2" value="GCASH">
																						<label class="form-check-label" for="inlineRadio2"><b>G-CASH</b></label>
																					</div>									 
																			<div class="modal-footer">
																			<input type="hidden" value="8" name="type">
																			<button type="button" class="btn btn-primary btn-radius btn-block btn-multi text-white" id="btn-meterpayment">Submit Payment</button>
																			</div>				
											</form>

											<center><a href="transactionhistory.php?mid=" onclick="this.href = this.href + document.getElementById('id_u_reading').value;">[View Readings History]</a> </center> </div>
 
						</div>		
		 

	 



                 	 <!--METER PAYMENT TAB 
                  <div class="tab-pane fade" id="custom-tabs-three-otherpurchase" role="tabpanel" aria-labelledby="custom-tabs-three-messages-tab">
                 other purchase</div>-->	

 

				
			</div>
			<br>
			<br>


																			</div></div></div>	</div>
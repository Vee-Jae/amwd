 <p id="success"></p>
  <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
				
					</div>
	 
                </div>
            </div>


   <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
            Unpaid <b>Accounts</b> 
        </h4>
	 
                <table id="waterbillpendings"  class="table table-striped table-bordered table-sm table-hover" cellspacing="0" width="100%">
             
                <thead>
                    <tr>
			 
				 
                 
						
					  <th  >Account</th>					
                   
                      <th >Account_holder</th>
                       <th >Current WB Bal.</th>   
					             <th >Total Paid</th>   
					              <th >Backlog Bal.</th>                   
                       <th >Status</th>
                      <th width="5%" >Action</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php
				$result = mysqli_query($conn,"SELECT *
        FROM    tbl_members_report a 
        WHERE      NOT EXISTS
                (
                SELECT  null 
                FROM    tbl_payments b  left join tbl_user_account c on b.unique_id = c.unique_id  
                WHERE   a.account_no = b.unique_id and a.reading_date =b.reading_date and  c.line_status = 1 
                );");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
	  
   <!--START OLD TABLE-->

   					<td><?php echo $row['unique_id'] ?></td>                    
               <td  >   <?php echo $row['acct_holder'] ?>
                                        
                    </td>
                  
                    
                     
                     <td>  <?php
 $unique_id=  $row['unique_id'] ;
//$sql_user_readings1 = "SELECT (SELECT SUM(`billing_amount`) FROM tbl_members_report  where account_no = '$unique_id' ) - (SELECT SUM(amount) FROM tbl_payments where unique_id = '$unique_id') AS total_billbalance";

//get bill payments  records
$sql_user_billrecord= "SELECT SUM(amount) as billspaidbalances FROM tbl_payments where unique_id = '$unique_id' and payment_type = 'WB'";
$result_user_billpay= mysqli_query($conn, $sql_user_billrecord);
$row_user_billpay = mysqli_fetch_assoc($result_user_billpay);

$sql_user_readings1 = "SELECT sum(billing_amount) as totalbills FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc";
$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
$row_user_readings3 = mysqli_fetch_assoc($result_user_details2);
$wpblance = $row_user_readings3['totalbills'] ;

$sql_user_bklogs = "SELECT sum(amount) as bklogtotal FROM tbl_backlogs_collection where account_no = '$unique_id' ";
$result_bl_details2 = mysqli_query($conn, $sql_user_bklogs);
$row_user_bklogread = mysqli_fetch_assoc($result_bl_details2);
$bklog = $row_user_bklogread['bklogtotal'];


$remainingbalance = $wpblance  + $bklog;
 
 
$billspayment = $row_user_billpay['billspaidbalances'];

$totalunpaidbill = $remainingbalance - $billspayment;
if ($totalunpaidbill > 0) {
 
 echo ' <b style="color:red">&#8369;'.$totalunpaidbill.  '</b>';


 
}else {

  echo ' <b text-sucess >&#8369; 0.00 </b>';


}

                     
                     ?> 
                      </td>
					  <td> <?php echo number_format(($billspayment));?></td>
            <td> <?php echo number_format(($bklog)); ?></td>

                         <td>

                         <?php
                         $linestatus = $row['line_status'] ;
                         if ($linestatus == 0) {
 ?>
 <a href="connection.php?con=1&&mid=<?php echo $row['unique_id'] ?>" 
 class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #df2525;
    border-radius: 10px; font-weight: bold; font-size: 10px;    ">Disconnected</a>

<?php

}elseif  ($linestatus== 1) {
 ?><a href="connection.php?con=0&&mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
  border-radius: 10px; font-weight: bold; font-size: 10px;    ">Connected</a> 
<?php

}
  ?>
  </td>

                     
                      <td>
               
					
 
                    <!-- <a href="prevtransactions.php?mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-dark btn-radius" > 
                      <i class="fas fa-history"></i> -->
					  <a href="#deleteEmployeeModal" class="delete btn btn-danger btn-radius" data-id="<?php echo $row["id"]; ?>" data-toggle="modal">
						<i class="fas fa-trash-alt" data-toggle="tooltip" 
						 title="Delete"></i></a>
</td>


                      <!--END OLD TABLE-->
					 
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>



        <tfoot id="waterbillpendings" class="table-dark">
        <tr>
				<th></th>
				<th></th>
				 <td> Total:</td>
           <td> </td>

 
					<td>   </td>
					<td> </td>
					<td> </td>
       
					 
					 
                    

            </tr>
       		 </tfoot>
			</table>
	 
        </div>
    </div>

  

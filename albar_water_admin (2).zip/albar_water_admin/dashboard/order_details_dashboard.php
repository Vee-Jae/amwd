<?php
 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 $datetoday = date('Y-m-d'); 

if (!isset($_SESSION['unique_id'])) { ?>
    <script language="javascript">
      window.location.href = '../index.php';
    </script>
<?php } 
$active_tab = "order";
$page = $_GET['page'];
?>  
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Order Details</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <link rel="icon" href="images/logo.png" type="image/png" sizes="16x16">
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="css/skeleton_loading.css">
<style type="text/css">
  .content-wrapper {
    background: #151e27!important;
  }
  @media(max-width:800px) {
    .modal-content {
      position: fixed; bottom: 40%; width: 96%; left: 7;
    }
    .modal-dialog {
      margin: 0!important; padding: 0!important;
    }
  }

</style>
</head>
<body class="hold-transition sidebar-mini layout-footer-fixed layout-fixed" style="background: #151e27;">
<div id="preloader" class="loading" style="display: none"></div>
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white" style="background: #151e27; border-bottom: 0; box-shadow: none!important;">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a href="<?php echo $page; ?>.php?<?php echo generate_string($permitted_chars, 100); ?>" class="withanimation back_arrow"><i class="fas fa-angle-left pr-2" style="font-size: 20px; color: #ffd700;"></i></a><span class="brand-text" style="font-size: 20px;"><span style="font-size: 20px; font-weight: bolder; line-height: 20px; color: #fff;">Order Details</span></a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </ul>
  </nav>

<?php include ("navbar.php")?>
<div class="content-wrapper">
<?php 
  $ordernumber = $_GET['ordernumber'];
  $sql_order_details = "SELECT * FROM tbl_user_checkout WHERE order_number = '$ordernumber'";
  $result_order_details = $conn->query($sql_order_details);
  $row_order = mysqli_fetch_assoc($result_order_details);
?>
  <section class="content-header">
    <div class="container-fluid">
      <span id="order_status">
        <?php if ($row_order['order_status'] == 0) { ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-clock text-warning" style="font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> Pending</h6>
            </div>
          </center>
        <?php }elseif($row_order['order_status'] == 1){ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-eye text-info" style="font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> Review</h6>
            </div>
          </center>
        <?php }elseif($row_order['order_status'] == 2){ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-check text-primary" style="font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> To Ship</h6>
            </div>
          </center>
        <?php }elseif($row_order['order_status'] == 3){ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-box text-warning" style="font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> To Deliver</h6>
            </div>
          </center>
        <?php }elseif($row_order['order_status'] == 4){ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-check-circle text-success" style="font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> Compelete</h6>
            </div>
          </center>
        <?php }else{ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-times-circle text-danger" style="font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> Canceled</h6>
            </div>
          </center>
        <?php } ?>
      </span>
    </div>
  </section>
  <section class="content">
    <div class="container-fluid pt-3">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card" style="background-color: #1d2532; color: #fff;">
             <div class="card-body pt-2">
              <p class="font-weight-bold mb-2 text-white">Customer Information</p>
                <hr style="margin-top: 3px; margin-bottom: 10px;">
                <div style="display: flex; justify-content: space-between; font-size: 15px;" class="mb-2">
                  <span style="padding-right: 60px;">Completename: </span>
                  <span style="text-align: right; font-weight: bolder;"><?php echo $row_order['completename']; ?></span>
                </div>

                <div style="display: flex; justify-content: space-between; font-size: 15px;" class="mb-2">
                  <span style="padding-right: 60px;">Mobilenumber: </span>
                  <span style="text-align: right; font-weight: bolder;"><?php echo $row_order['contactnumber']; ?></span>
                </div>

                <div style="display: flex; justify-content: space-between; font-size: 15px;" class="mb-2">
                  <span style="padding-right: 60px;">Address: </span>
                  <span style="text-align: right; font-weight: bolder;"><?php echo $row_order['complete_address']; ?></span>
                </div>
              </div>
          </div>

          <div class="card" style="background-color: #1d2532;">
             <div class="card-body pt-2">
              <p class="font-weight-bold mb-2 text-white">Order Details</p>
                <div style="display: flex; justify-content: space-between; font-size: 14px;" >
                  <span class="pt-1 text-white">Total</span>
                  <span style="text-align: right; font-weight: bolder; font-size: 20px; color: #fff;">&#8369; <?php echo number_format(($row_order['order_total'])) ?>.00</span>
                </div>
                <hr style="margin-top: 3px; margin-bottom: 10px;">
                <table class="table p-0" style="font-weight: bold; font-size: 14px;">
                  <?php 
                    $sql_cart = "SELECT * FROM tbl_user_checkout_details WHERE order_number = '$ordernumber'";
                    $result_cart = $conn->query($sql_cart);
                      while($row_cart = mysqli_fetch_array($result_cart)) {
                      $product_id = $row_cart['product_id'];

                        $sql_product_details = "SELECT * FROM tbl_product WHERE product_id = '$product_id'";
                        $result_product_details = mysqli_query($conn, $sql_product_details);
                        $row_product_details = mysqli_fetch_assoc($result_product_details);
                  ?>
                  <tr>
                    <td class="text-white" style="border-top: 0!important; padding-left: 0;"><?php echo $row_cart['quantity'] ?>x</td>
                    <td class="text-white" style="border-top: 0!important;"><?php echo $row_product_details['product_name'] ?></td>
                    <td class="text-white" style="border-top: 0!important; text-align: right; padding-right: 0;"><span style="font-size: 12px; font-weight: normal;">&#8369;</span> <?php echo $row_cart['price'] * $row_cart['quantity']; ?>.00</td>
                  </tr>
                  <?php } ?>
                </table>
              </div>
          </div>

        </div>
      </div>
    </div>
  </section>
</div>
</div>

<script src="dist/js/adminlte.min.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="plugins/jquery-validation/additional-methods.min.js"></script>
<script src="dist/js/pages/dashboard.js"></script>
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {

});
$(function () {
  $(".withanimation").click(function(e) {
      e.preventDefault();
      $(".loading").show();
      var url=$(this).attr("href");
      setTimeout(function() {
          window.location=url;
      }, 500);
  });
});
</script>
</body>
</html>

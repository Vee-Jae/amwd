 


 

	<p id="success"></p>
  <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
				
					</div>
				<!--	<div class="col-sm-6">
						 <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons"></i> <span>Add New Account</span></a>  
						<a href="JavaScript:void(0);" class="btn btn-danger" id="delete_multiple"><i class="material-icons"></i> <span>Delete</span></a>						
					</div> -->
                </div>
            </div>


   <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
            Water <b>Bills</b> 
        </h4>


                <table id="example1" class="table table-bordered table-hover">
             
                <thead>
                    <tr>
						<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th> 
				 
                 
						
					  <th  >Account #</th>					
                   
                      <th >Account Holder.</th>
					  <th> MD Balance
					 
                      <th >WB Balance</th>                   
                       <th >Status</th>
                      <th width="20%" >Action</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php
				$result = mysqli_query($conn,"SELECT * FROM tbl_user_account order by unique_id desc");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
				<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td>
					 


   <!--START OLD TABLE-->

   					<td><?php echo $row['unique_id'] ?></td>                    
                     
                      <td  >   <?php echo $row['acct_holder'] ?>
                                        
                    </td>
                  
                     <td>
						<?php
						$unique_id=  $row['unique_id'] ;
						$sql_user_billrecord= "SELECT SUM(amount) as feepaidbalances FROM tbl_payments where payment_type = 'MD' and unique_id = '$unique_id'";
						$result_user_billpay= mysqli_query($conn, $sql_user_billrecord);
						$row_user_billpay_summary = mysqli_fetch_assoc($result_user_billpay);
						
						$sql_user_readings1 = "SELECT sum(fee) as totalfee FROM tbl_meterdevice where account_no = '$unique_id' ";
						$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
						$row_user_readings_summary = mysqli_fetch_assoc($result_user_details2);
						
						$remainingbalance_summary = $row_user_readings_summary['totalfee'];
						$billspayment_summary = $row_user_billpay_summary['feepaidbalances'];
						
						$totalmeterfee = $remainingbalance_summary - $billspayment_summary;
						
								if ($totalmeterfee > 0) {
								
									echo ' <b style="color:red">&#8369;'.$totalmeterfee.  '</b>';
								
								
									
								}else {
								
									echo ' <b text-sucess >&#8369; 0.00 </b>';
								
								
								}
														
						?>
					</td>
                     
                     <td>  <?php
 $unique_id=  $row['unique_id'] ;
//$sql_user_readings1 = "SELECT (SELECT SUM(`billing_amount`) FROM tbl_members_report  where account_no = '$unique_id' ) - (SELECT SUM(amount) FROM tbl_payments where unique_id = '$unique_id') AS total_billbalance";

//get bill payments  records
$sql_user_billrecord= "SELECT SUM(amount) as billspaidbalances FROM tbl_payments where unique_id = '$unique_id' and payment_type = 'WB'";
$result_user_billpay= mysqli_query($conn, $sql_user_billrecord);
$row_user_billpay = mysqli_fetch_assoc($result_user_billpay);

$sql_user_readings1 = "SELECT sum(billing_amount) as totalbills FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc";
$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
$row_user_readings3 = mysqli_fetch_assoc($result_user_details2);

$remainingbalance = $row_user_readings3['totalbills'];
$billspayment = $row_user_billpay['billspaidbalances'];

$totalunpaidbill = $remainingbalance - $billspayment;
if ($totalunpaidbill > 0) {
 
 echo ' <b style="color:red">&#8369;'.$totalunpaidbill.  '</b>';


 
}else {

  echo ' <b text-sucess >&#8369; 0.00 </b>';


}

                     
                     ?> 
                      </td>
                   

                         <td>

                         <?php
                         $linestatus = $row['line_status'] ;
                         if ($linestatus == 0) {
 
 echo '<a href="upgrade.php?mid='.$row['id'].'&&pkg='.$row['package'].'" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #df2525;
    border-radius: 10px; font-weight: bold; font-size: 10px;    ">Disconnected</a>';



}elseif  ($linestatus== 1) {
  echo '<a href="#" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
  border-radius: 10px; font-weight: bold; font-size: 10px;    ">Connected</a>';


}
  ?>
  </td>
                     
                      <td>
                     
 
                  

					  <a href="#addmetertModal" class="addmeterreading btn  btn-outline-dark"
					     	data-accountno="<?php echo $row["unique_id"]; ?>"
							data-name="<?php echo $row["acct_holder"]; ?>"
							data-prevreading="<?php echo $row['pres_reading']; ?>"							
 							title="addmeterreading1"
							 data-toggle="modal"> 
							<i class="fas fa-tachometer-alt"data-toggle="tooltip"></i> </a>  


					  <a href="#addPaymentModal" class="addpayment btn  btn-outline-warning" 
					  		data-id="<?php echo $row["unique_id"]; ?>"
							data-name="<?php echo $row["acct_holder"]; ?>"
						 	title="addpayment1" 
							data-toggle="modal"> 

							<i class="fas fa-money-bill-alt"data-toggle="tooltip"></i> </a>  
      

					  <a href="#editEmployeeModal" class="edit btn btn-outline-success btn-radius"
					        data-id="<?php echo $row["id"]; ?>"
							data-name="<?php echo $row["name"]; ?>"
							data-email="<?php echo $row["email"]; ?>"
							data-phone="<?php echo $row["phone"]; ?>"
							data-city="<?php echo $row["city"]; ?>"
							title="Edit"
							data-toggle="modal">
							<i class="fas fa-edit update" data-toggle="tooltip"> 
							</i>
						</a>

				


 
                     <a href="prevtransactions.php?mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-dark btn-radius" > 
                      <i class="fas fa-history"></i>
					  <a href="#deleteEmployeeModal" class="delete btn btn-danger btn-radius" data-id="<?php echo $row["id"]; ?>" data-toggle="modal">
						<i class="fas fa-trash-alt" data-toggle="tooltip" 
						 title="Delete"></i></a>
</td>


                      <!--END OLD TABLE-->
					 
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
	 
        </div>
    </div>

 <?php include 'add_billspayment.php';?>
 <?php include 'add_meterreading.php';?> 
 <?php include 'add_account.php';?> 

 
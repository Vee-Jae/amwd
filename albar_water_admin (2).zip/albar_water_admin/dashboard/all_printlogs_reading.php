 


 

	<p id="success"></p>
  <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
				
					</div>
			 
                </div>
            </div>


   <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
              <b>Reading Transaction Count: </b>  <?php echo number_format(($rowtotalread));  ?>
        </h4>

	 
                <table id="example1"  class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
             
                <thead>
                    <tr>
					<!--	<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th> -->
				 
						<th  >#</th>
						
					  <th  >Account</th>					
                      <th >reading_date</th>
					  <th> account_name</th> 
					   <th >prev_reading</th>                   
                       <th >pres_reading</th>
					   <th >total_reading</th>
					   <th >billing_amount</th>
                      <th width="20%" >Action</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php
 
				$result = mysqli_query($conn,"SELECT* from tbl_members_report where transaction_date= '$datetoday' order by id desc ");
			 
				
				$i=1;
					while($row = mysqli_fetch_array($result)) {

					$reading_date      =	$row['reading_date'] ;
					$transaction_date    =	$row['transaction_date'] ;
					$account_no      =	$row['account_no'] ;
					$account_name       =	$row['account_name'] ;
					$prev_reading   =	$row['prev_reading']; 
					$pres_reading   =	$row['pres_reading'] ;
					$total_reading   =	$row['total_reading']; 
					$billing_amount =	$row['billing_amount'] ;
					$due_date =	$row['due_date'] ;
					$disconnection_date =	$row['disconnection_date'] ;
					 

				 
				?>
			 <tr 
			 ?>
			 
			 
		 
						<td><?php echo $i; ?></td>  

   <!--START OLD TABLE-->

   					<td><?php echo $row['account_no'] ?></td>                    
                     
                      <td  >   <?php echo $row['reading_date'] ?>  </td>
                  
                     <td>   <?php echo $row['account_name'] ?>	</td>
                     
                     <td> <?php echo $row['prev_reading'] ?>   
                      </td>
					  <td> <?php echo $row['pres_reading'] ?>   
                      </td>
                   

                         <td>  <?php echo $row['total_reading'] ?>  </td>
						 <td>  <?php echo $row['billing_amount'] ?>  </td>
                     
                      <td> <a href="printreceipt_reading.php?mid=<?php echo $account_no; ?>&acctholder=<?php echo $account_name;?>&pres_reading=<?php echo $pres_reading;?>&prev_reading=<?php echo $prev_reading;?>&total_reading=<?php echo $total_reading;?>&billing_amount=<?php echo $billing_amount;?>&reading_date=<?php echo $reading_date;?>&duedate=<?php echo $due_date;?>&disconnection=<?php echo $disconnection_date;?>"><i class="fas fa-print"></i> </a></td>


                      <!--END OLD TABLE-->
					 
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
	 
        </div>
    </div>
 
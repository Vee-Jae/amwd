 


 

	<p id="success"></p>
    <section class="content">
 
   
  <div class="container-fluid">


  <label for="datepost">Select Reading Date:</label>
           
            <form action="" method= "POST">
            <select  class="form-control" name="select_readingdate2"  aria-label="Default select example">
              <option value="" selected disabled>Select Date</option>
              <?php    if (!isset($_GET['dat']))
                   {
                        $result = mysqli_query($conn , "SELECT * FROM tbl_reading_sched order by  id desc");
                   }
                    $cnt = 0 ;
                    while( $row = mysqli_fetch_array($result) )
                    {
                        $cnt++;

                        ?>
                       
                         <option value="<?php echo $row['reading_date'] ?>"><?php echo $row['reading_date']  ?></option>
                <?php } ?>
             </select>
             <button type="submit" class="btn btn-primary btn-radius btn-block btn-multi text-white" name="submitincreading">Generate Report</button>
					
              </form>



    
      <div class="col-lg-12 col-12">
        <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
          <div class="inner">
              <h4 style="mx-auto" >
              <b>Reading Date:   <?php echo $generateddate2 .' count: '. number_format(($totalpendingct)); ?>
                
          </h4>
  
       
                   <table id="example2" class="table table-bordered table-hover">
             
                  <thead>
                      <tr>
                     
                   
                          <th  >#</th>
                          
                        <th  >Account</th>					
                      
                        <th> account_name</th> 
                         <th >prev_reading</th> 
                         <th >Status</th>                   
                       
                        <th width="20%" >Action</th>
                      </tr>
                  </thead>
                  <tbody>
                  
                  <?php
   
                $result = mysqli_query($conn,"SELECT * from tbl_user_account  where  NOT EXISTS  (  SELECT * FROM  tbl_members_report  WHERE     reading_date = '$generateddate2'  AND  tbl_user_account.unique_id = tbl_members_report.account_no   )and line_status = 1" );
               
                  
                  $i=1;
                      while($row = mysqli_fetch_array($result)) {
  
                      $reading_date      =	$row['tbl_user_account.unique_id'] ;
                      $transaction_date    =	$row['tbl_user_account.acct_holder'] ;
                       
                      $prevreading    =	$row['tbl_user_account.pres_reading'] ;
                       
  
                   
                  ?>
               <tr id="<?php echo $i; ?>"> 
           
                       
                          <td><?php echo $i; ?></td>  
  
     <!--START OLD TABLE-->
  
                         <td><?php echo $row['unique_id'] ?></td>                    
                       
                        <td  >   <?php echo $row['acct_holder'] ?>  </td>
                    
                       <td>   <?php echo $row['pres_reading'] ?>	</td>
                       
                       <td> 
                         <?php
                         $linestatus = $row['line_status'] ;
                         if ($linestatus == 0) {
                          ?>
                          <a href="connection.php?con=1&&mid=<?php echo $row['unique_id'] ?>" 
                          class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #df2525;
                              border-radius: 10px; font-weight: bold; font-size: 10px;    ">Disconnected</a>

                          <?php

                          }elseif  ($linestatus== 1) {
                          ?><a href="connection.php?con=0&&mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-success btn-radius" style="color: #fff;border-color: #ffffff; background: #03c500;
                            border-radius: 10px; font-weight: bold; font-size: 10px;    ">Connected</a> 
                          <?php

                          }
                            ?> </td>
                       
                        <td> <a href="printreceipt_reading.php?mid=<?php echo $account_no; ?>&&acctholder=<?php echo $account_name;?>&&pres_reading=<?php echo $pres_reading;?>&&prev_reading=<?php echo $prev_reading;?>&&total_reading=<?php echo $total_reading;?>&&billing_amount=<?php echo $billing_amount;?>&&reading_date=<?php echo $reading_date;?>&&duedate=<?php echo $due_date;?>&&disconnection=<?php echo $disconnection_date;?>"><i class="fas fa-print"></i> </a></td>
  
  
                        <!--END OLD TABLE-->
                       
                  </tr>
                  <?php
                  $i++;
                  }
                  ?>
                  </tbody>
                
                  <tfoot id="example2" class="table-dark">
          	  <tr>
				<th></th>
				<th></th>
				
				 <th scope="row">Total</th>
     
                <td><!--sum matching-->
				<?php
					 
					 $sumgc = "SELECT sum(pres_reading) as sumpending from tbl_user_account  where  NOT EXISTS  (  SELECT * FROM  tbl_members_report  WHERE     reading_date = '$generateddate2'  AND  tbl_user_account.unique_id = tbl_members_report.account_no   )and line_status = 1;";
					 $result_sumgc= mysqli_query($conn, $sumgc);
					 $rowgcsum = mysqli_fetch_assoc($result_sumgc);
					 
					 echo   number_format(($rowgcsum['sumpending']));
					 
					 ?>
					 
					</td>

 
					<td>  
					 
					</td>
					<td> </td>
					 
					 
                    

            </tr>
       		 </tfoot>
            
          </table>
       
          </div>
      </div>
   <section>
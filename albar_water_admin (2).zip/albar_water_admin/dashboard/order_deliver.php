            <div class="card mt-3" style="border-radius: 10px; background-color: #1d2532; color: #fff;" id="order_full_screen">
              <div class="card-body table-responsive p-3">
                  <table id="delivery_table" class="table table-hover">
                    <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer</th>
                      <th>Customer Details</th>
                      <th>Date</th>
                      <th width="22%">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php 
                      $sql_order = "SELECT * FROM tbl_user_checkout WHERE order_status = '3'";
                      $result_order = $conn->query($sql_order);
                        while($row_order = mysqli_fetch_array($result_order)) {
                          $ordernumber = $row_order['order_number'];
                    ?>
                    <tr>
                      <td><?php echo $row_order['order_number']; ?></td>
                      <td><?php echo $row_order['completename']; ?></td>
                      <td>
                        <?php echo $row_order['contactnumber']; ?><br>
                        <?php echo $row_order['complete_address']; ?>
                      </td>
                      <td><?php echo date('F d Y', strtotime($row_order['date_checkout'])); ?></td>
                      <td>
                        <a data-toggle="modal" data-target="#status<?php echo $row_order['id']; ?>" class="btn btn-sm btn-primary">Mark Complete</a>

                        <a data-toggle="modal" data-target="#order<?php echo $row_order['id']; ?>" class="btn btn-sm btn-info">View Order</a>
                      </td>
                    </tr>

                    <div class="modal" id="order<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Order Details</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0">
                            <div style="display: flex; justify-content: space-between;">
                              <span class="text-white">Total:</span>
                              <span class="text-white" style="font-size: 20px; font-weight: bolder;">&#8369; <?php echo number_format(($row_order['order_total'])) ?>.00</span>
                            </div>
                            <?php 
                                $sql_cart = "SELECT * FROM tbl_user_checkout_details WHERE order_number = '$ordernumber'";
                                $result_cart = $conn->query($sql_cart);
                                  while($row_cart = mysqli_fetch_array($result_cart)) {
                                  $product_id = $row_cart['product_id'];
                                    $sql_product_details = "SELECT * FROM tbl_product WHERE product_id = '$product_id'";
                                    $result_product_details = mysqli_query($conn, $sql_product_details);
                                    $row_product_details = mysqli_fetch_assoc($result_product_details);
                            ?>
                            <div class="txn-history">
                              <p class="txn-list">
                                <span class="text-white">QTY: <b><?php echo $row_cart['quantity']; ?>x</b></span>
                                <span class="transaction-amount"><span class="text-white">Item: <b><?php echo $row_product_details['product_name']; ?></span>
                              </p>
                            </div>
                            <?php } ?>
                          </div>
                          <div class="modal-footer" style="border: 0px">
                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="modal" id="status<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Mark Complete</h5>
                          </div>
                          <form style="margin: 0px;" method="POST" id="myform">
                          <input type="hidden" name="id" value="<?php echo $row_order['id']; ?>">
                          <div class="modal-body pt-2 pb-0">
                            <p class="text-muted">Are you sure you want to mark complete?</p>
                            <input type="hidden" name="status" value="4"/>
                          </div>
                          <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                            <div class="row">
                              <div class="col-6">
                                <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                              </div>
                              <div class="col-6">
                                <button type="submit" name="save" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                              </div>
                            </div>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>

          <div id="order_small_screen" style="display: none;">
            <?php
              $sql_order = "SELECT * FROM tbl_user_checkout WHERE order_status = '3'";
              $result_order = $conn->query($sql_order);
              if ($result_order->num_rows > 0) { ?>
                <div class="input-group mb-3 mt-3">
                  <div class="input-group-prepend">
                    <button class="btn bg-white" style="border-top-left-radius: 10px; border-bottom-left-radius: 10px;" type="submit" name="search"><i class="fas fa-search" ></i></button>
                  </div>
                  <input type="text" class="form-control border-left-0" id="deliver_search" placeholder="Search Order number..." required/>
                </div>
            <?php } ?>

            <span id="deliver_result">  
            <?php
              $sql_order = "SELECT * FROM tbl_user_checkout WHERE order_status = '3'";
              $result_order = $conn->query($sql_order);
              if ($result_order->num_rows > 0) {
                while($row_order = mysqli_fetch_array($result_order)) {
                  $ordernumber = $row_order['order_number'];
            ?>
              <a data-toggle="modal" data-target="#modalnew<?php echo $row_order['id']; ?>">
                <div class="txn-history">
                  <p class="txn-list">
                    <span class="text-white">Order ID: </span><span class="transaction-amount" style="color: #ffd700;"><?php echo $row_order['order_number']; ?></span><br>
                    <span class="text-white">Customer: </span><span class="transaction-amount"><?php echo $row_order['completename']; ?></span><br>
                    <span class="text-white">Mobile Number: </span><span class="transaction-amount"><?php echo $row_order['contactnumber']; ?></span><br>
                    <span class="text-white">Address: </span><span class="transaction-amount"><?php echo $row_order['complete_address']; ?></span><br>
                  </p>
                </div>
              </a>
                    <div class="modal" id="modalnew<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Choose Action</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0"></div>
                          <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                            <div class="row">
                              <div class="col-6">
                                <button type="button" id="status_btn<?php echo $row_order['id']; ?>" data-toggle="modal" data-target="#status_small<?php echo $row_order['id']; ?>" class="btn btn-primary btn-lg btn-block">Complete</button>
                              </div>
                              <div class="col-6">
                                <button type="button" id="order_btn<?php echo $row_order['id']; ?>" data-toggle="modal" data-target="#order_small<?php echo $row_order['id']; ?>" id="view_order_btn<?php echo $row_order['id']; ?>" class="btn btn-info btn-lg btn-block">View Order</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>     

                    <div class="modal" id="status_small<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Mark Complete</h5>
                          </div>
                          <form style="margin: 0px;" method="POST" id="myform">
                          <input type="hidden" name="id" value="<?php echo $row_order['id']; ?>">
                          <div class="modal-body pt-2 pb-0">
                            <p class="text-muted">Are you sure you want to mark complete?</p>
                            <input type="hidden" name="status" value="4"/>
                          </div>
                          <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                            <div class="row">
                              <div class="col-6">
                                <button type="button" id="close<?php echo $row_order['id'] ?>" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                              </div>
                              <div class="col-6">
                                <button type="submit" name="save" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                              </div>
                            </div>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>   

                    <div class="modal" id="order_small<?php echo $row_order['id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Order Details</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0">
                            <div style="display: flex; justify-content: space-between;">
                              <span class="text-white">Total:</span>
                              <span class="text-white" style="font-size: 20px; font-weight: bolder;">&#8369; <?php echo number_format(($row_order['order_total'])) ?>.00</span>
                            </div>
                            <?php 
                                $sql_cart = "SELECT * FROM tbl_user_checkout_details WHERE order_number = '$ordernumber'";
                                $result_cart = $conn->query($sql_cart);
                                  while($row_cart = mysqli_fetch_array($result_cart)) {
                                  $product_id = $row_cart['product_id'];
                                    $sql_product_details = "SELECT * FROM tbl_product WHERE product_id = '$product_id'";
                                    $result_product_details = mysqli_query($conn, $sql_product_details);
                                    $row_product_details = mysqli_fetch_assoc($result_product_details);
                            ?>
                            <div class="txn-history">
                              <p class="txn-list">
                                <span class="text-white">QTY: <b><?php echo $row_cart['quantity']; ?>x</b></span>
                                <span class="transaction-amount"><span class="text-white">Item: <b><?php echo $row_product_details['product_name']; ?></span>
                              </p>
                            </div>
                            <?php } ?>
                          </div>
                          <div class="modal-footer" style="border: 0px">
                            <button type="button" <?php if($row_order['order_status'] == 0) { ?> id="close_order<?php echo $row_order['id'] ?>" <?php } ?> class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>

      <script type="text/javascript">
        $(document).ready(function(){
          $('#status_btn<?php echo $row_order['id'] ?>').click(function() {
            $('#modalnew<?php echo $row_order['id']; ?>').modal('hide');
          });

          $('#order_btn<?php echo $row_order['id'] ?>').click(function() {
            $('#modalnew<?php echo $row_order['id']; ?>').modal('hide');
          });

          $('#close_order<?php echo $row_order['id'] ?>').click(function() {
            $('#modalnew<?php echo $row_order['id']; ?>').modal('show');
          });

          $('#close<?php echo $row_order['id'] ?>').click(function() {
            $('#modalnew<?php echo $row_order['id']; ?>').modal('show');
          });
        });
      </script>    
        <?php } }else{ ?>
          <center>
              <div class="text-center error-content p-3">
                <i class="fas fa-box-open text-warning" style="margin-top: 100px; margin-bottom: 10px; font-size: 80px;"></i>
                <h6 class="font-weight-bold text-white"> No To Deliver Order.</h6>
            </div>
          </center>
        <?php } ?>
      </div>
<script type="text/javascript">
$(document).ready(function () {
  $('#deliver_search').keyup(function() {
    var deliver = $(this).val();
    var btn_action = "deliver_search";
     $.ajax({
      url:'search_order.php',
      method:"POST",
      dataType:"html",
      data:{deliver:deliver, btn_action:btn_action},
      success:function(data){
        $('#deliver_result').html(data);
      }
    });
  });
});
  $(function () {
    $("#delivery_table").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
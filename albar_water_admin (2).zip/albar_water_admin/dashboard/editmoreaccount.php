<?php

ini_set('session.gc_maxlifetime', 360000);
// each client should remember their session id for EXACTLY 4days
session_set_cookie_params(360000);
$page = 'home';
$menu = 'no';



if(isset($_SESSION['username']))
{
  header("location:index.php");
}


 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 $datetoday = date('Y-m-d'); 
 $active_tab = "dashboard"; 
 $unique_id = $_GET["mid"];

$sql_user_details = "SELECT * FROM tbl_user_account WHERE unique_id = '$unique_id'";
$result_user_details = mysqli_query($conn, $sql_user_details);
$row_user_details = mysqli_fetch_assoc($result_user_details);

$acct_holder_1 = $row_user_details['acct_holder'];
$firstname_1 = $row_user_details['firstname'];
$lastname_1 = $row_user_details['lastname'];
$pres_reading = $row_user_details['pres_reading'];
$mobilenumber = $row_user_details['mobilenumber'];
$home_address = $row_user_details['home_address'];
$line_status = $row_user_details['line_status'];



 if (isset($_POST['save_data'])) {
  
 $fee = $_POST ['fee'];
 $paid = $_POST ['paid'];
 $remaining_balance = $_POST ['remaining_balance'];

 
 $insert_newrecord= "INSERT INTO tbl_meterdevice (account_no,fee,meter_type,date_encoded ) 
 VALUES('$unique_id','$fee' ,'Backlog','$datetoday')";
 mysqli_query($conn, $insert_newrecord);
 


 $insert_newrecord2= "INSERT INTO tbl_payments (unique_id,payment_type,amount,payment_date,payment_option,date_encoded) 
 VALUES('$unique_id','MD' ,'$paid','$datetoday','CASH','$datetoday')";
 mysqli_query($conn, $insert_newrecord2);

  ?>
  <script language="javascript">
        window.location.href = 'index.php';
      </script>
      <?php
 }

 

 
 if (isset($_POST['save_data2'])) {
  
  $fee = $_POST ['fee'];
  $readingdate = $_POST['readingdate'];
 
  $insert_newrecord= "INSERT INTO tbl_backlogs_collection (account_no,reading_date,amount,transaction_date,type ) 
  VALUES('$unique_id','$readingdate' ,'$fee','$datetoday','WB')";
  mysqli_query($conn, $insert_newrecord);
  
  
 
   ?>
   <script language="javascript">
         window.location.href = 'index.php';
       </script>
       <?php
  }



  if (isset($_POST['save_personal_data'])) {
    // Retrieve form data 
    $acct_holder_user = $_POST['acct_holder_user'];
    $primary_owner_fname = $_POST['primary_owner_fname'];
    $primary_owner_lname = $_POST['primary_owner_lname'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $currentid = $_GET["mid"];
    $update_reading= "UPDATE tbl_user_account SET
    acct_holder = '$acct_holder_user',
    firstname = '$primary_owner_fname',
    lastname = '$primary_owner_lname',
    mobilenumber = '$mobile',
    home_address = '$address'
    WHERE unique_id = '$currentid'";
   
    if (mysqli_query($conn, $update_reading)) {
    $success_messages = '<script type="text/javascript">
    swal({
        title: "Product Updated Successfully!",
        text: "refereshing in 2 seconds.",
        type: "success",
        timer: 2000,
        showConfirmButton: false,
      }).then(function() {
         
        window.location.href = "more.php";
    });
</script>';
} else {
$success_messages = '<script type="text/javascript">
    swal({
        title: "Failed to update!",
        text: "Kindly Check if you missed any details",
        type: "info"
    });
</script>';
}
}
 
  
  
?>  
<html>
<head>
<body class="hold-transition   layout-footer-fixed layout-fixed sidebar-collapse">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
 
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">


  <?php include_once('linkStyle.php'); ?>
  
<style>
  .currencyinput {
    border: 1px inset #ccc;
}
.currencyinput input {
    border: 0;
}
  </style>
<div id="preloader" class="loading" style="display: none"></div>
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white" style="background: #151e27; border-bottom: 0; box-shadow: none!important;">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a href="more.php?<?php echo generate_string($permitted_chars, 100); ?>" class="withanimation"><i class="fas fa-angle-left pr-2" style="font-size: 20px; color: #ffd700;"></i></a><span class="brand-text" style="font-size: 20px;"><span style="font-size: 20px; font-weight: bolder; line-height: 20px; color: #fff;">
      Edit Members Details and Records</span></a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </ul>
  </nav>

<?php include ("navbar.php")?>
<div class="content-wrapper">
  <section class="content menu-main">
    <div class="container-fluid">
      <div class="pt-2"></div>
      <div style="display: flex; justify-content: space-between;">
       
        <a class="information" data-toggle="tooltip" data-placement="left" title="Please tap the image to choose new profile."><i class="fas fa-info-circle pt-1" style="font-size: 20px; color: grey;"></i></a>
      </div>
      <div class="text-center pt-2">
            

            <span id="message">
            <?php echo $success_messages ;?>

            </span>
      </div>
    </div><!-- /.container-fluid -->
  </section>


  <div class="col-12 col-sm-12">
            <div class="card card-primary card-outline card-outline-tabs">
                        <div class="card-header p-0 border-bottom-0">
                          <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                          
                          <li class="nav-item">
                              <a class="nav-link active" id="custom-tabs-four-accnt-tab" data-toggle="pill" href="#custom-tabs-four-accnt" role="tab" aria-controls="custom-tabs-four-accnt" aria-selected="true">Account Details</a>
                            </li>
                            
                            <li class="nav-item">
                              <a class="nav-link " id="custom-tabs-four-home-tab" data-toggle="pill" href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home" aria-selected="true">Meter Device</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="custom-tabs-four-profile-tab" data-toggle="pill" href="#custom-tabs-four-profile" role="tab" aria-controls="custom-tabs-four-profile" aria-selected="false">Water Bills</a>
                            </li>
          
                            </li>
                          </ul>
                        </div>



 <div class="tab-content" id="custom-tabs-four-tabContent">



 <div class="tab-pane fade show active " id="custom-tabs-four-accnt" role="tabpanel" aria-labelledby="custom-tabs-four-accnt-tab">
                        
                        
                                                            
                                                            
                        <!--content tab1-->  
                        <section class="content">
                            <div class="container-fluid pt-0 pb-0 pl-3 pr-3">
                           
                           
                             <form action="" method="POST" id="userDetails">
                            
                          
                               <div class="form-group">
                              
                            <label class="label">Account #:</label>
                                <input type="text" name="acct_num"  value="<?php echo $unique_id; ?>" class="form-control"   />
                                </div>

                        

                                <div class="form-group">
                                <label class="label">Account Holder User:

                                </label>
                                <input type="text" name="acct_holder_user" class="form-control"    value="<?php echo $acct_holder_1; ?>"/>
                                </div>

                                <div class="form-group">
                                <label class="label">Primary Owner Firstname</label>
                                <input type="text" name="primary_owner_fname" class="form-control"    value="<?php echo $firstname_1; ?>"/>  
                                </div>

                                <div class="form-group">
                                <label class="label">Primary Owner Lastname</label>
                                <input type="text" name="primary_owner_lname"    class="form-control"   value="<?php echo $lastname_1; ?>"   />
                              
                                </div>

                                <div class="form-group">
                                <label class="label">Mobile Number</label>
                                <input type="text" name="mobile"    class="form-control"    value="<?php echo $mobilenumber; ?>"   />
                             
                                </div>
                                <div class="form-group">
                                <label class="label">Complete Address</label>
                                <input type="text" name="address"   class="form-control"  value="<?php echo $home_address; ?>"  />
                               
                                </div>
                        

                                <button type="button" data-toggle="modal" data-target="#update_info2" class="btn btn-success btn-block btn-lg" style=" border-color: #ffd700;">Update Record</button>

                                <div class="modal" id="update_info2">
                                <div class="modal-dialog">
                                    <div class="modal-content" style="background-color: #151e27!important;">
                                    <div class="modal-header pb-0" style="border: 0px;">
                                        <h5 class="modal-title text-white" style="font-weight: bold;">Update Members Record</h5>
                                    </div>
                                    <div class="modal-body pt-0 pb-0">
                                        <p class="text-muted">Are you sure you want to update changes in this account?</p>
                                    </div>
                                    <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                                        <div class="row">
                                        <div class="col-6">
                                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                                        </div>
                                        <div class="col-6">
                                            <button type="submit" name="save_personal_data" class="btn btn-primary btn-lg btn-block withanimation_submit" style="  border-color: #ffd700;">Yes, Submit</button>
                                        </div>
                                        </div>
                                        
                                    </div>
                                    </div>
                                </div>
                                </div> <!-- logout -->

                            </form>
                            </div>
                        </section>

                        <!--end content tab1-->


</div>



  <div class="tab-pane fade " id="custom-tabs-four-home" role="tabpanel" aria-labelledby="custom-tabs-four-home-tab">
                        
                        
                                                            
                                                            
                                    <!--content tab1-->  
                                    <section class="content">
                                        <div class="container-fluid pt-0 pb-0 pl-3 pr-3">
                                        <form method="POST" id="userDetails">
                                        
                                            <div class="form-group">
                                            <label class="label">Account #:</label>
                                            <input type="text" name="acct"  value="<?php echo $unique_id; ?>" class="form-control"   readonly/>
                                            </div>

                                    

                                            <div class="form-group">
                                            <label class="label">Add Fee:</label>
                                            <input type="number" name="fee" class="form-control" id="id-2"   placeholder="0"/>
                                            </div>

                                            <div class="form-group">
                                            <label class="label">Amount Paid</label>
                                            <input type="number" name="paid" class="form-control" id="id-1"  value="0"   />
                                            </div>

                                            <div class="form-group">
                                            <label class="label">Remaining Balance</label>
                                            <input type="number" name="remaining_balance" id="id-3"   class="form-control"   readonly/>
                                            </div>
                                    

                                            <button type="button" data-toggle="modal" data-target="#update_info2" class="btn btn-primary btn-block btn-lg" style=" border-color: #ffd700;">Save Changes</button>

                                            <div class="modal" id="update_info2">
                                            <div class="modal-dialog">
                                                <div class="modal-content" style="background-color: #151e27!important;">
                                                <div class="modal-header pb-0" style="border: 0px;">
                                                    <h5 class="modal-title text-white" style="font-weight: bold;">Add New Record</h5>
                                                </div>
                                                <div class="modal-body pt-0 pb-0">
                                                    <p class="text-muted">Are you sure you want to add this record?</p>
                                                </div>
                                                <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                                                    <div class="row">
                                                    <div class="col-6">
                                                        <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                                                    </div>
                                                    <div class="col-6">
                                                        <button type="submit" name="save_data" class="btn btn-primary btn-lg btn-block withanimation_submit" style="  border-color: #ffd700;">Yes, Submit</button>
                                                    </div>
                                                    </div>
                                                    
                                                </div>
                                                </div>
                                            </div>
                                            </div> <!-- logout -->

                                        </form>
                                        </div>
                                    </section>

                                    <!--end content tab1-->


</div>









 <div class="tab-pane fade" id="custom-tabs-four-profile" role="tabpanel" aria-labelledby="custom-tabs-four-profile-tab">
  <!--content tab2-->  
  <section class="content">
    <div class="container-fluid pt-0 pb-0 pl-3 pr-3">
      <form method="POST" id="userDetails">
      
        <div class="form-group">
          <label class="label">Account #:</label>
          <input type="text" name="acct"  value="<?php echo $unique_id; ?>" class="form-control"   readonly/>
        </div>

 

        <div class="form-group">
          <label class="label">Balance Amount</label>
          <input type="number" name="fee" class="form-control" id="id-2"   placeholder="0"/>
        </div>

    

        <div class="form-group">
          <label class="label">Reading Date</label>
          <input type="date" name="readingdate" id="id-3"   class="form-control"   />
        </div>
 

        <button type="button" data-toggle="modal" data-target="#update_info" class="btn btn-warning btn-block btn-lg" style="background: #FFD700; border-color: #ffd700;">Save Changes</button>

        <div class="modal" id="update_info">
          <div class="modal-dialog">
            <div class="modal-content" style="background-color: #151e27!important;">
              <div class="modal-header pb-0" style="border: 0px;">
                <h5 class="modal-title text-white" style="font-weight: bold;">Add New Record</h5>
              </div>
              <div class="modal-body pt-0 pb-0">
                <p class="text-muted">Are you sure you want to add this record?</p>
              </div>
              <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                <div class="row">
                  <div class="col-6">
                    <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                  </div>
                  <div class="col-6">
                    <button type="submit" name="save_data2" class="btn btn-primary btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div> <!-- logout -->

      </form>
    </div>
  </section> <!--end tab 2-->
  </div>



   </div>
  </div>
  
            </div>
  </div>



  
 

</div>
</div>

<script src="dist/js/adminlte.min.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="plugins/jquery-validation/additional-methods.min.js"></script>
<script src="dist/js/pages/dashboard.js"></script>
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script type="text/javascript">

 

$(function () {
  $("#id-1, #id-2, #id-3,#id-4,#id-5").keyup(function () {
      (+$("#id-3").val
    (+$("#id-2").val() - +$("#id-1").val())) ;
  
    (+$("#id-5").val
    (+$("#id-3").val() * +$("#id-4").val())) ;

  });
});
</script>
</script>
</body>
</html>

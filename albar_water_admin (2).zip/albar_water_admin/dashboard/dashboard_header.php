x        <div class="row">
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-2" style="background: #1d2532!important;">
                    <span class="bg-info mt-3 mb-3 ml-2" style="border-radius: 50%; padding: 10px;">
                        <i class="fas fa-paper-plane" style="font-size:20px"></i>
                    </span>

                    <div class="info-box-content pl-3">
                        <span class="info-box-text text-muted" style="font-size: 15px">Payout Request</span>
                        <?php 
                  $sql_encashment_request = "SELECT * FROM tbl_request_encashment WHERE status = 0";
                  $result_encashment_request = $conn->query($sql_encashment_request);
                ?>
                        <span class="info-box-number text-white"
                            style="font-size: 18px"><?php echo $result_encashment_request->num_rows; ?></span>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-2" style="background: #1d2532!important;">
                    <span class="bg-success mt-3 mb-3 ml-2" style="border-radius: 50%; padding: 10px;">
                        <i class="fas fa-check" style="font-size:20px"></i>
                    </span>

                    <div class="info-box-content pl-3">
                        <span class="info-box-text text-muted" style="font-size: 15px">Completed Orders</span>
                        <span class="info-box-number text-white" style="font-size: 18px">0</span>
                    </div>
                </div>
            </div>

            <div class="clearfix hidden-md-up"></div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-2" style="background: #1d2532!important;">
                    <span class="bg-primary mt-3 mb-3 ml-2" style="border-radius: 50%; padding: 10px;">
                        <i class="fas fa-shopping-cart" style="font-size:20px"></i>
                    </span>

                    <div class="info-box-content pl-3">
                        <span class="info-box-text text-muted" style="font-size: 15px">Sales</span>
                        <span class="info-box-number text-white" style="font-size: 18px">0</span>
                    </div>
                </div>
            </div>





            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-2" style="background: #1d2532!important;">
                    <span class="bg-warning mt-3 mb-3 ml-2" style="border-radius: 50%; padding: 10px;">
                        <i class="fas fa-users" style="font-size:20px"></i>
                    </span>

                    <div class="info-box-content pl-3">
                        <?php 
                  $sql_count_members = "SELECT COUNT(DISTINCT firstname,lastname) as totalcount    FROM `tbl_user_account` where user_type != 1";
                  $result_refer_detailsB = mysqli_query($conn, $sql_count_members);
                  $result_count_members = mysqli_fetch_assoc($result_refer_detailsB);
                  $totalcount  = $result_count_members['totalcount'];
                ?>
                        <span class="info-box-text text-muted"
                            style="font-size: 15px">Member<?php if($totalcount > 1){ echo 's'; } ?></span>
                        <span class="info-box-number text-white"
                            style="font-size: 18px"><?php echo $totalcount ?></span>
                    </div>
                </div>


            </div>



            
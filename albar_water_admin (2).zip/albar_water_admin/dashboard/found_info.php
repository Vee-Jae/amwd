<section class="content bg-white pt-1 pb-2 mt-2">

<div class="container-fluid">
		<div class="row">
		 
 

 
<?php

$sqlYourDetails = "SELECT * FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc ";
$resultYourDetails = $conn->query($sqlYourDetails);
$rowYourDetails = mysqli_fetch_assoc($resultYourDetails);

$fullname = $rowYourDetails['uname'];
$first_num = $rowYourDetails['prev_reading'];
$second_num = $_POST['second_num'];
$operator = $_POST['operator'];
$result = '';

if (is_numeric($first_num) && is_numeric($second_num)) {
    switch ($operator) {
        case "Calculate":
           $result = ($second_num - $first_num ) * 75;
            break;
        case "Subtract":
           $result = $first_num - $second_num;
            break;
        case "Multiply":
            $result = $first_num * $second_num;
            break;
        case "Divide":
            $result = $first_num / $second_num;
    }
}

echo 'Account Number:'. $memberaccountno.'<br>';
echo  'Members Name:'. $rowYourDetails['account_name'].'<br>';   
echo  'Registered  Mobile:'. $rowYourDetails['mobilenumber'].'<br>';   
?>

 
 
	  <form action="" method="post" id="quiz-form">
            <p>
			<b>Previous Reading: <?php echo $first_num; ?></b>
                <input type="hidden" name="first_num" id="first_num" required="required" value="<?php echo $first_num; ?>" />
            </p>
            <p>
			<b>Enter Current Reading: </b>
                <input type="number" name="second_num" id="second_num" required="required" value="<?php echo $second_num; ?>" /> 
            </p>
            <p><b>Result: </b>
                <input readonly="readonly" name="result" value="<?php echo $result; ?>"> 

                <input type='text' name="result" name="mobilenumber" value="<?php echo $rowYourDetails['mobilenumber']; ?>"> 
            </p>
			<div class="form-group">
            <div class="col-6">
            <input type="submit" name="operator" value="Calculate" class="btn btn-warning btn-block"   />
			</div>
            </div>

		 
		
		</div>
        
	


    </div>

	<div class="form-group">
        

    <div class="col-6">
                    <button type="submit" name="Submit" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;"> Submit Reading</button>
                  </div>
                </div>
		
		</div>
	</div>

    </form>
</section>

<style type="text/css">
  .sidebar-dark-primary .nav-sidebar>.nav-item>.nav-link.active{
    background: #ffd700!important;
    color: #000!important;
  }
  .brand-link:hover {
    color: #fff!important;
  }
  
 /* custom scrollbar */
::-webkit-scrollbar {
  width: 20px;
}

::-webkit-scrollbar-track {
  background-color: transparent;
}

::-webkit-scrollbar-thumb {
  background-color: #d6dee1;
  border-radius: 20px;
  border: 6px solid transparent;
  background-clip: content-box;
}

::-webkit-scrollbar-thumb:hover {
  background-color: #a8bbbf;
}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background: #151e27;">
    <!-- Brand Logo -->
    <a class="brand-link">
   
      <span class="brand-text font-weight-light" style="font-size: 17px;">Admin<B style="color:#ffd700;"> Tool</B></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <!--  <div class="info">
          <a href="account.php?<?php echo generate_string($permitted_chars, 100) ?>" class="d-block withanimation"><?php echo $firstname.' '.$lastname ?> <span>( Profile )</span></a>
          <small class="text-center" style="color:white;">Click to view Profile</small>
        </div>
      </div> -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item">
            <a href="index.php?<?php echo generate_string($permitted_chars, 100); ?>" class="nav-link <?php if($active_tab == "dashboard") { echo 'active'; } ?> withanimation">
              <i class="nav-icon fas fa-tachometer-alt text-dark"></i>
              <p>
                Home
              </p>
            </a>
          </li>


    

 

          <li class="nav-item">
            <a href="#?<?php echo generate_string($permitted_chars, 100); ?>" class="nav-link <?php if($active_tab == "members") { echo 'active'; } ?> withanimation">
              <i class="nav-icon fas fa-users text-dark"></i>
              <p>
                Members List 
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="#?<?php echo generate_string($permitted_chars, 100); ?>" class="nav-link <?php if($active_tab == "report") { echo 'active'; } ?> withanimation">
              <i class="nav-icon fas fa-users text-dark"></i>
              <p>
                Reports
              </p>
            </a>
          </li>

       


          <li class="nav-item">
            <a href="#?<?php echo generate_string($permitted_chars, 100); ?>" class="nav-link withanimation">
              <i class="nav-icon fas fa-history text-dark"></i>
              <p>
                Transaction History
              </p>
            </a>
          </li>

       
          <li class="nav-item">
            <a href="logout.php?<?php echo generate_string($permitted_chars, 100); ?>" class="nav-link withanimation">
              <i class="nav-icon fas fa-history text-dark"></i>
              <p>
               Logout
              </p>
            </a>
          </li>
 
    

 

        </ul>
      </nav>
    </div>
    <!-- /.sidebar -->
  </aside>

<?php
require_once('../connect.php');
$getcon = $_GET["con"];
$mid = $_GET["mid"];

$sql_update = "UPDATE tbl_user_account SET line_status = '$getcon' where unique_id = '$mid'";
if (mysqli_query($conn, $sql_update)) 
{?>
    <script language="javascript">
        window.location.href = 'index.php';
      </script>
      <?php
    }

    
?>

 
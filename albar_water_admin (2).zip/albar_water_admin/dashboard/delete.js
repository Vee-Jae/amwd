$(document).on("click", ".deletebillspay", function () {
  var recordid = $(this).attr("data-id");
  swal({
    title: "Are you sure?",
    text: "Once deleted, you will not be able to recover this Record!!!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "all_data_delete.php",
        type: "POST",
        cache: false,
        data: {
          type: 3,
          id: recordid,
        },
        success: function (dataResult) {
          location.reload();

          $("#" + dataResult).remove();
        },
      });
      swal("Record Deleted successfully !", {
        icon: "success",
      });
    } else {
      swal("Your record is safe");
    }
  });
});

$(document).on("click", ".deletereading", function () {
  var readingid = $(this).attr("data-id");
  swal({
    title: "Are you sure?",
    text: "Once deleted, you will not be able to recover this Record!!!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "all_data_delete.php",
        type: "POST",
        cache: false,
        data: {
          type: 6,
          id: readingid,
        },
        success: function (dataResult) {
          location.reload();

          $("#" + dataResult).remove();
        },
      });
      swal("Record Deleted successfully !", {
        icon: "success",
      });
    } else {
      swal("Your record is safe");
    }
  });
});




 

$(document).on("click", "#delete_multiple", function () {
  var user = [];
  $(".user_checkbox:checked").each(function () {
    user.push($(this).data("user-id"));
  });
  if (user.length <= 0) {
    alert("Please select records.");
  } else {
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this Record !",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        var selected_values = user.join(",");
        //console.log(selected_values);
        $.ajax({
          type: "POST",
          url: "all_data_delete.php",
          cache: false,
          data: {
            type: 4,
            id: selected_values,
          },
          success: function (response) {
            var ids = response.split(",");
            for (var i = 0; i < ids.length; i++) {
              $("#" + ids[i]).remove();
            }
          },
        });
        location.reload();
        swal("Record Deleted successfully !", {
          icon: "success",
        });
      } else {
        swal("Cancelled! Your data is safe!");
      }
    });
  }
});
$(document).ready(function () {
  $('[data-toggle="tooltip"]').tooltip();
  var checkbox = $('table tbody input[type="checkbox"]');
  $("#selectAll").click(function () {
    if (this.checked) {
      checkbox.each(function () {
        this.checked = true;
      });
    } else {
      checkbox.each(function () {
        this.checked = false;
      });
    }
  });
  checkbox.click(function () {
    if (!this.checked) {
      $("#selectAll").prop("checked", false);
    }
  });
});

    <footer class="main-footer pb-2 pr-0 pl-0 pt-3 footer-nav" style="background: #212121;box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12)!important;">
       <div class="row text-center">
         <div class="col-lg-3 col-3">
          <a href="indexcollection.php" 
" class="footer-nav <?php if($page == 'home') { echo 'active-footer'; } ?> click-link">
            <i class="fa fa-tachometer-alt"></i>
            <p class="mb-0 mt-1 fontSize-13">Dashboard</p>
          </a>
        </div>

        <div class="col-lg-3 col-3">
          <a href="printlogs.php" 
" class="footer-nav <?php if($page == 'seller_wallet') { echo 'active-footer'; } ?> click-link">
            <i class="fas fa-money-bill-alt"></i>
            <p class="mb-0 mt-1 fontSize-13">Payments</p>
          </a>
        </div>

        <div class="col-lg-3 col-3">

        <?php if (($_SESSION['username'] == 'superadmin')) {
          ?>
        

        <a href="sortreadings.php" 
" class="footer-nav <?php if($page == 'wallet') { echo 'active-footer'; } ?> click-link">
            <i class="fas fa-wallet"></i>
            <p class="mb-0 mt-1 fontSize-13">Reading</p>
          </a>
<?php }else {?>

          <a href="printlogs_reading.php" 
" class="footer-nav <?php if($page == 'wallet') { echo 'active-footer'; } ?> click-link">
            <i class="fas fa-wallet"></i>
            <p class="mb-0 mt-1 fontSize-13">Reading</p>
          </a>

          <?php } ?>
        </div>

       
         <?php if (($_SESSION['username'] == 'MainAdmin')) {
          ?>
           <div class="col-lg-3 col-3">
           <a href="more.php" 
class="footer-nav <?php if($page == 'more') { echo 'active-footer'; } ?> click-link">
<i class="fa fa-user"></i>
<p class="mb-0 mt-1 fontSize-13">More</p> </a>
</div>
<?php
          
         }else {?>
 <div class="col-lg-3 col-3">
          <a href="indexcollection.php" 
 class="footer-nav <?php if($page == 'more') { echo 'active-footer'; } ?> click-link">

             <i class="fas fa-pen"></i>
            <p class="mb-0 mt-1 fontSize-13">Reports</p>
          </a>
        </div>
        <?php
         }?>

         
      </div>
    </footer>
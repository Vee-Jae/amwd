
	<!-- Add Payment TAB HTML -->
	<div id="addotherbalance" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form_meterreading">

                                <div class="modal-header">						
                                <h4 class="modal-title">Add Backlog Balance</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                </div>
                                 <div class="modal-body">	
                                               <div class="row">
                                                <div class="col-sm-3">
                                                    <label for="datepost">Account#: </label>
                                                    <input type="text" id="id_u_reading" name="id" class="form-control" readonly>	
                            
                                                </div>
                                                <div class="col-sm-8">
                                                        <label for="datepost">Account Holder: </label>
                                                        <input type="text" id="txt_acct_holder1" name="acctholder"  class="form-control" readonly>	
                                                </div>
                                                </div>
                                 </div>
                             
                                <br>
                     
                                    <br>
                            
                        

            
                                       
               </form>   
                    
                 
              </div>
        </div>
    </div>
    <br>
    <br>



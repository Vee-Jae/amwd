<?php
include 'bd.php';
date_default_timezone_set('Asia/Manila');
$datetoday = date('Y-m-d'); 

if(count($_POST)>0){
	if($_POST['type']==1){
		$acctnumber=$_POST['acctnumber'];
		$accntholder=$_POST['accntholder'];
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$address=$_POST['address'];

		$sql = "INSERT INTO `tbl_user_account`( unique_id,acct_holder,firstname,lastname,pres_reading,home_address,date_registered,line_status) 
		VALUES ('$acctnumber','$accntholder','$fname','$lname','0','$address','$datetoday','0')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$city=$_POST['city'];
		$sql = "UPDATE `tbl_user_account` SET `name`='$name',`email`='$email',`phone`='$phone',`city`='$city' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM `tbl_user_account` WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM tbl_user_account WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}



if(count($_POST)>0){
	if($_POST['type']==5){
		$id=$_POST['id'];
		$waterbill_amount=$_POST['waterbill_amount'];
		$payment_date=$_POST['payment_date'];
		$image_url=$_POST['image_url'];
		$modeofpay=$_POST['modeofpay'];
		$select_readingdate=$_POST['select_readingdate'];

 		 $upload_image=$_FILES['waterbill_image_url']['name'];
		 $folder='waterbill_receipt/';
		 move_uploaded_file($_FILES['waterbill_image_url']['tmp_name'],'$folder'.$_FILES['waterbill_image_url']['name']);

		 
		 
		$sql = "INSERT INTO `tbl_payments`( `unique_id`, `payment_type`,`amount`,`payment_date`,`reading_date`,`receipt_url`,`item_details`,`payment_option`,`date_encoded`) 
		VALUES ('$id','WB','$waterbill_amount','$payment_date','$select_readingdate','NA','NA','$modeofpay','$datetoday')";
		if (mysqli_query($conn, $sql)) {
			move_uploaded_file($tempname, $folder);
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
} 




if(count($_POST)>0){
	if($_POST['type']==8){
		$id=$_POST['id'];
		$meterpayment_amount=$_POST['waterbill_amount'];
		$payment_date=$_POST['payment_date'];
		$image_url=$_POST['image_url'];
		$modeofpay=$_POST['modeofpay'];
		$select_readingdate=$_POST['select_readingdate'];

	  
 
		 
		$sql = "INSERT INTO `tbl_payments`( `unique_id`, `payment_type`,`amount`,`payment_date`,`receipt_url`,`item_details`,`payment_option`) 
		VALUES ('$id','MD','$meterpayment_amount','$payment_date','NA','NA','$modeofpay')";
		if (mysqli_query($conn, $sql)) {
			 
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}




//insert new reading
if(count($_POST)>0){
	if($_POST['type']==7){
		$id=$_POST['id'];
		$postdate=$_POST['postdate'];
		$duedate=$_POST['duedate'];
		$disconnection=$_POST['disconnection'];

		$acctholder=$_POST['acctholder'];
		$prev_reading=$_POST['prev_reading'];
		$newreading=$_POST['newreading'];
		$reading_result=$_POST['reading_result'];
		$reading_result_bill=$_POST['reading_result_bill'];


	 $sql_newreadingcount = "SELECT * FROM `tbl_members_report` where reading_date = '$postdate' and account_no = '$id'  ";
$result = mysqli_query($conn, $sql_newreadingcount);
$rowtotalexist = mysqli_num_rows($result);
//
if ($rowtotalexist > 0) {

	

}else {
		$sql_update = "UPDATE tbl_user_account SET pres_reading = '$newreading' WHERE unique_id = '$id'";
		 mysqli_query($conn, $sql_update);

		 if ($reading_result < 5 ) {
			$reading_result_bill = 300;
		   }else {
		  
		   }


		   $sql = "INSERT INTO tbl_members_report( reading_date, account_no,account_name,prev_reading,pres_reading,total_reading,billing_amount,transaction_date,due_date,disconnection_date) 
		   VALUES ('$postdate','$id','$acctholder','$prev_reading','$newreading','$reading_result','$reading_result_bill','$datetoday','$duedate','$disconnection')";
		   if (mysqli_query($conn, $sql)) {
			
			   echo json_encode(array("statusCode"=>200));
		   } 
		   else {
			   echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		   }
		   mysqli_close($conn);



	}



		 
	
	}
}


?>
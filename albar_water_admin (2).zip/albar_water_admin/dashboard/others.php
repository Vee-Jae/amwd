
<div class="modal fade" id="others">
          <div class="modal-dialog">
            <div class="modal-content btn-radius">
           <div class="modal-header pb-0 " style="border: 0px;">
           <center>  <h5 class="modal-title" style="font-weight: bold; text-align:center"></h5> 
              </div> 
              <div class="modal-body pt-0 pb-0">

              <b>Select Report</b>
			  <small><p>  </p></small><HR>
			

			  <div class="row">

					

						<div class="col-3 col-md-3">
                       
						<a href="#"   data-toggle="modal" id="action"  data-target="#contactus"  class="btn-icontop-lg btn-close"  data-mdb-dismiss="modal" >
							<span  style="font-size: 40px; color: #4f8d47;"> 
							<i class="fas fa-wifi"></i>
							</span><br>
							<span class="text text-truncate mt-2">
							<small class="text-dark"><b>Connected</b></small>
							</span>
						</a>
						</div>


						<div class="col-3 col-md-3">
						<a href="#"  data-toggle="modal" id="action"  data-target="#contactus"    class="btn-icontop-lg btn-close"  data-mdb-dismiss="modal" >
						<span  style="font-size: 40px; color: #dd6b45;"> 
						<i class="fas fa-times-octagon"></i>
						</span><br>
						<span class="text text-truncate mt-2" >
						<small class="text-dark"><b>Disconnected  </b></small>
						</span>
						</a>
						</div>

						<div class="col-3 col-md-3">
						<a href="#"  data-toggle="modal" id="action"  data-target="#contactus"    class="btn-icontop-lg btn-close"  data-mdb-dismiss="modal" >
							<span  style="font-size: 40px; color: #d8c81b;"> 
							<i class="fa fa-ship"></i>
							</span><br>
							<span class="text text-truncate mt-2">
							<small class="text-dark"><b>Readings</b></small>
							</span>
						</a>
						</div>


						<div class="col-3 col-md-3">
						<a href="#"  data-toggle="modal" id="action"  data-target="#contactus"    class="btn-icontop-lg btn-close"  data-mdb-dismiss="modal" >
							<span  style="font-size: 40px; color: #d8c81b;"> 
							<i class="fa fa-ship"></i>
							</span><br>
							<span class="text text-truncate mt-2">
							<small class="text-dark"><b>Payments</b></small>
							</span>
						</a>
						</div>


					 

</div>
               
<br> 

</div>
</div>
</div>
</div> </center> 
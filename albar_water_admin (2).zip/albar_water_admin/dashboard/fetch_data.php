<?php
 session_start();
 require_once('../connect.php');

if (isset($_POST['btn_action'])) {
	if ($_POST['btn_action'] == 'member_search') {
		$search_member = mysqli_real_escape_string($conn, $_POST['members']);

		if ($search_member == '') {
			$sql_members = "SELECT * FROM tbl_user_account WHERE user_type != '1' ";
		}else{
			$sql_members = "SELECT * FROM tbl_user_account WHERE unique_id LIKE '%$search_member%' AND user_type != '1'"; 
		}
		$result_members = $conn->query($sql_members);
		if ($result_members->num_rows > 0) {
			while($row_members_new = mysqli_fetch_array($result_members)) {
                echo '<a data-toggle="modal" data-target="#member_small_new'.$row_members_new['id'].'">
                        <div class="txn-history font-weight-bold">
                          <p class="txn-list">
                            <span class="text-white" style="font-weight: normal;">Unique ID: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_members_new['unique_id'].'</span><br>
                            <span class="text-white" style="font-weight: normal;">Completename: </span><span class="transaction-amount">'.$row_members_new['firstname'].' '.$row_members_new['lastname'].'</span><br>
                            <span class="text-white" style="font-weight: normal;">Mobile Number: </span><span class="transaction-amount">'.$row_members_new['mobilenumber'].'</span><br>
                          </p>
                        </div>
                      </a>

                      <div class="modal" id="member_small_new'.$row_members_new['id'].'">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Member Details</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0">
                            
                            <div class="txn-history">
                              <p class="txn-list">
                                <span class="text-white">Address: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_members_new['complete_address'].'</span><br>
                                <span class="text-white">Referral: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_members_new['direct_referral'].'</span><br>
                                <span class="text-white">Placement: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_members_new['placement'].'</span><br>
                                <span class="text-white">Activation Code: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_members_new['verification_code'].'</span><br>
                              </p>
                            </div>
                  
                          </div>
                          <div class="modal-footer" style="border: 0px">
                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>';
			}
		}else{
            echo '<center>
                    <div class="text-center error-content p-3">
                        <i class="fas fa-box-open text-warning" style="margin-top: 100px; margin-bottom: 10px; font-size: 80px;"></i>
                        <h6 class="font-weight-bold text-white"> No Member.</h6>
                    </div>
                  </center>';
		}
	}


  if ($_POST['btn_action'] == 'pending_search') {
    $pending_request = mysqli_real_escape_string($conn, $_POST['pending_request']);

    if ($pending_request == '') {
      $sql_pending = "SELECT * FROM tbl_request_encashment WHERE status = 0";
    }else{
      $sql_pending = "SELECT * FROM tbl_request_encashment WHERE request_unique_code LIKE '%$pending_request%' AND status = 0";
    }
    $result_pending = $conn->query($sql_pending);
    if ($result_pending->num_rows > 0) {
      while($row_pending_req = mysqli_fetch_array($result_pending)) {
        $user_id = $row_pending_req['unique_id'];

        $sql_user = "SELECT * FROM tbl_user_account WHERE unique_id = '$user_id'";
        $result_user = $conn->query($sql_user);
        $row_user = mysqli_fetch_assoc($result_user);
                echo '<a data-toggle="modal" data-target="#approve_new'.$row_pending_req['id'].'">
                        <div class="txn-history font-weight-bold ml-2 mr-2">
                          <p class="txn-list">
                            <span class="text-white" style="font-weight: normal;">Request ID: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_pending_req['request_unique_code'].'</span><br>
                            <span class="text-white" style="font-weight: normal;">Completename: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_user['firstname'].' '.$row_user['lastname'].'</span><br>
                            <span class="text-white" style="font-weight: normal;">Amount: </span><span class="transaction-amount" style="color: #ffd700;">&#8369; '.number_format(($row_pending_req['amount'])).'</span><br>
                            <span class="text-white" style="font-weight: normal;">Date Request: </span><span class="transaction-amount" style="color: #ffd700;">'.date('F d Y', strtotime($row_pending_req['date_request'])).'</span><br>
                          </p>
                        </div>
                      </a>

                      <div class="modal" id="approve_new'.$row_pending_req['id'].'">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-color: #151e27!important;">
                            <div class="modal-header pb-0" style="border: 0px;">
                              <h5 class="modal-title text-white" style="font-weight: bold;">Approve Request</h5>
                            </div>
                            <div class="modal-body pt-0 pb-0">
                              <p class="text-muted">Are you sure you want to approve request?</p>
                            </div>
                            <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                              <div class="row">
                                <div class="col-6">
                                  <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                                </div>
                                <div class="col-6">
                                  <form style="margin: 0;" method="POST">
                                    <input type="hidden" name="id" value="'.$row_pending_req['id'].'">
                                    <input type="hidden" name="total_credit" value="'.$row_pending_req['amount'].'">
                                    <input type="hidden" name="unique_id" value="'.$row_pending_req['unique_id'].'">
                                    <button type="submit" name="approve" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>';
      }
    }else{
            echo '<center>
                    <div class="text-center error-content p-3">
                        <i class="fas fa-box-open text-warning" style="margin-top: 30px; margin-bottom: 10px; font-size: 80px;"></i>
                        <h6 class="font-weight-bold text-white"> Search not found.</h6>
                        <br><br>
                    </div>
                  </center>';
    }

  }

  if ($_POST['btn_action'] == 'approve_search') {
    $approve_request = mysqli_real_escape_string($conn, $_POST['approve_request']);

    if ($approve_request == '') {
      $sql_pending = "SELECT * FROM tbl_request_encashment WHERE status = 1";
    }else{
      $sql_pending = "SELECT * FROM tbl_request_encashment WHERE request_unique_code LIKE '%$approve_request%' AND status = 1";
    }
    $result_pending = $conn->query($sql_pending);
    if ($result_pending->num_rows > 0) {
      while($row_pending_req = mysqli_fetch_array($result_pending)) {
        $user_id = $row_pending_req['unique_id'];

        $sql_user = "SELECT * FROM tbl_user_account WHERE unique_id = '$user_id'";
        $result_user = $conn->query($sql_user);
        $row_user = mysqli_fetch_assoc($result_user);
                echo '<a>
                        <div class="txn-history font-weight-bold ml-2 mr-2">
                          <p class="txn-list">
                            <span class="text-white" style="font-weight: normal;">Request ID: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_pending_req['request_unique_code'].'</span><br>
                            <span class="text-white" style="font-weight: normal;">Completename: </span><span class="transaction-amount" style="color: #ffd700;">'.$row_user['firstname'].' '.$row_user['lastname'].'</span><br>
                            <span class="text-white" style="font-weight: normal;">Amount: </span><span class="transaction-amount" style="color: #ffd700;">&#8369; '.number_format(($row_pending_req['amount'])).'</span><br>
                            <span class="text-white" style="font-weight: normal;">Date Request: </span><span class="transaction-amount" style="color: #ffd700;">'.date('F d Y', strtotime($row_pending_req['date_request'])).'</span><br>
                          </p>
                        </div>
                      </a>';
      }
    }else{
            echo '<center>
                    <div class="text-center error-content p-3">
                        <i class="fas fa-box-open text-warning" style="margin-top: 30px; margin-bottom: 10px; font-size: 80px;"></i>
                        <h6 class="font-weight-bold text-white"> Search not found.</h6>
                        <br><br>
                    </div>
                  </center>';
    }

  }

echo "<script type='text/javascript'>
        $(function () {
          $('.withanimation_submit').click(function() {
              $('.loading').show();
          });
        });
      </script>";
}
?>
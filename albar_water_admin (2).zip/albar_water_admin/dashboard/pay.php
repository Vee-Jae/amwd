<?php 



ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);


ini_set('session.gc_maxlifetime', 360000);
// each client should remember their session id for EXACTLY 4days
session_set_cookie_params(360000);
session_start();
 
require_once('../connect.php');
require_once('sql_required.php');

$datetoday = date('d F Y, h:i A'); 
$active_tab = "dashboard"; 


  
$error = '';
$success = '';
$balanceerror = '';



$sqlreading_date = "SELECT * FROM tbl_reading_sched WHERE status = 1";
$result_user_details = mysqli_query($conn, $sqlreading_date);
$row_user_detailsread = mysqli_fetch_assoc($result_user_details);
$c_readingdate = $row_user_detailsread['reading_date'];




 
$unique_id = $_GET['mid'];
$sql_user_details = "SELECT * FROM tbl_user_account WHERE unique_id = '$unique_id'";
$result_user_details = mysqli_query($conn, $sql_user_details);
$row_user_details = mysqli_fetch_assoc($result_user_details);
$acct_holder = $row_user_details['acct_holder'];


$sql_user_readings = "SELECT * FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc";
$result_user_details = mysqli_query($conn, $sql_user_readings);
$row_user_readings = mysqli_fetch_assoc($result_user_details);

$prev_reading = $row_user_readings['prev_reading'];
$pres_reading = $row_user_readings['pres_reading'];
$total_reading = $row_user_readings['total_reading'];
$reading_date = $row_user_readings['reading_date'];
$_cubic = $row_user_readings['75_cubic'];
$billing_amount = $row_user_readings['billing_amount'];

$amount_paid = $row_user_readings['amount_paid'];


$sql_user_readings1 = "SELECT sum(balance) as remainingbalance FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc";
$result_user_details2 = mysqli_query($conn, $sql_user_readings1);
$row_user_readings3 = mysqli_fetch_assoc($result_user_details2);

$remainingbalance = $row_user_readings3['remainingbalance'];


$sqlYourDetails = "SELECT * FROM tbl_members_report WHERE account_no = '$unique_id' order by reading_date desc limit 1 ";
$resultYourDetails = $conn->query($sqlYourDetails);
$rowYourDetails = mysqli_fetch_assoc($resultYourDetails);

$fullname = $rowYourDetails['uname'];
$first_num = $rowYourDetails['pres_reading'];
$second_num = $_POST['second_num'];

$operator = $_POST['operator'];
$result = '';

if (is_numeric($first_num) && is_numeric($second_num)) {
    switch ($operator) {
        case "Calculate":
           $result = ($second_num - $first_num ) * 75;
            break;
        case "Subtract":
           $result = $first_num - $second_num;
            break;
        case "Multiply":
            $result = $first_num * $second_num;
            break;
        case "Divide":
            $result = $first_num / $second_num;
    }
}
 
 
if (isset($_POST['save_data'])) {
  $postdate = $_POST['postdate'];
  $current_reading = $_POST['second_num'];
  $reading_result = $_POST['reading_result'];
  $postdate = $_POST['postdate'];
  $currentid = $_GET['mid'];
 
 


$totalbill = $reading_result * 75;
  $insert_newrecord= "INSERT INTO tbl_members_report (reading_date,account_no,account_name,prev_reading,
  pres_reading,total_reading,75_cubic,billing_amount,amount_paid,balance,due_date,disconnection_date ) 
  VALUES('$c_readingdate','$currentid' ,'$acct_holder' ,'$pres_reading' , '$current_reading','$reading_result','$totalbill','$totalbill',0,'$totalbill','$c_due_date','$c_disconnection_date')";
  mysqli_query($conn, $insert_newrecord);
  
}
?>
<!DOCTYPE html>

<html>
<head><meta charset="utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><title>
	Purchase
</title><meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="userJs/jquery.min.js"></script>
    <script src="userJs/jquery-ui.min.js"></script>

    
    <?php include_once('linkStyle.php'); ?>
  
    <!--Start of Tawk.to Script-->

    
    <!--End of Tawk.to Script-->
</head>
<body class="hold-transition   layout-footer-fixed layout-fixed sidebar-collapse">

<div id="preloader" style="display:none;"></div>
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item maxBars">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item ml-2">
        <span class="brand-text title-form-brand font-weight-bolder fontSize-20">Dashboard</span>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item minBars">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item dropdown" id="dropDownFullScreen">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fas fa-user"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <i class="fas fa-user mr-2"></i> 
            <span class="text-muted text-sm">Profile</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="../logout.php" class="dropdown-item dropdown-footer">Logout</a>
        </div>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
  <?php 
  include_once('navbar.php'); 

  
  
  ?>


 
 
        <div class="wrapper">
          
            </div>
        
            <div class="content-wrapper">

                
    <div class="content-header">
      
      <section class="content">




 <form method="POST" enctype="multipart/form-data" id="subscriptionForm">

        <div class="container-fluid">
            <div class="card card-info color-palette-box">

           

        <center>   <?php 
                echo  $success ;
                echo $balanceerror;
                
                ?>    </center>
                <div class="card-header">
                    <h3 class="card-title">Add Payment Record</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">

                          

                            <div class="row form-group">
                                <div class="col-sm-12">
                              <b> Account Holder:</b>  <?php echo $acct_holder ?>
                                <br><b> Previous Reading Date:</b> <?php echo $reading_date; ?>
                  
                             
                          


<br> 
                                 
  
<a href="#" class="btn btn-outline-dark btn-radius" data-toggle="modal" data-target="#modal_table" > 
                          View Other Records    <i class="fas fa-edit"></i> </a>
</div>
</div>

<hr>
                            <div class="row form-group">
                                <div class="col-sm-12">
                             
                              
 
 
           
            <div class="form-group">
            <div class="col-12">
            <label for="datepost">Reading Date:</label>
            <input type="text" class="form-control"  id="postdate" name="postdate" value="<?php echo $c_readingdate?>" readonly>
		   
                <input type="hidden" name="first_num" id="first_num" required="required" value="<?php echo $first_num; ?>" /> 
           
                <br>   <b> Last Reading: </b><b style="color:red;">  <?php echo $pres_reading; ?>  </b><br>

                <input type="hidden" id="id-1" value="<?php echo $pres_reading; ?>" />


 
            <b>Enter Current Reading: </b>
                <input type="number" name="second_num" id="id-2" class="form-control"  required="required" value="<?php echo $second_num; ?>" required /> 
            
            <!--  <input type="submit" name="operator" value="Calculate" class="btn btn-warning btn-block"   />  
              <br> -->
             <b>Total Reading: </b>

             
                <input type="number" readonly="readonly" name="reading_result" class="form-control"   id="id-3"  > 


   
                

			</div>
            </div>
          
 
 
           </div>    </div>

 
               <div class="col-12">
                  <button type="button" id="action" data-toggle="modal" data-target="#requestModal" class="btn btn-danger btn-radius btn-block btn-multi text-white"  >Submit Record</button>
                </div>

                






                             <!--   <button class="btn btn-primary" style="margin-top:30px; margin-left: 10px;" onclick = "buypkg()" >Activate</button> -->

          <div class="modal" id="requestModal">
            <div class="modal-dialog">
              <div class="modal-content btn-radius">
                <div class="modal-header pb-0" style="border: 0px;">
                  <h5 class="modal-title" style="font-weight: bold;">Submit Record</h5>
                </div>
                <input type="hidden" name="myemail"   class="form-control" placeholder="email" autocomplete="off" value=<?php echo $_SESSION['email']; ?>>
                <div class="modal-body pt-0 pb-0">
                  <p class="text-muted">Are you sure you want to submit proceed?</p>
                </div>
                <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                  <div class="row">
                    <div class="col-6">
                      <button type="button" class="btn btn-default btn-block btn-save bg-white" data-dismiss="modal">Cancel</button>
                    </div>
                    <div class="col-6">
                      <input type="hidden" name="save_data" value="save">
                      <button type="submit" id="action" class="btn btn-success btn-save btn-block">
                        <span id="button-text">Yes, Submit</span>
                      </button>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
  </form>
       

          <!--MODAL SEARCH-->
          <div class="modal" id="modal_table">
            <div class="modal-dialog">
              <div class="modal-content btn-radius">
                <div class="modal-header pb-0" style="border: 0px;">
                  <h5 class="modal-title" style="font-weight: bold;">All Records</h5>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                 <?php include ("all_records_search.php");?>

                  </div>
                </div>
              </div>
            </div>
          </div>
           <!--MODAL SEARCH-->
      




          
                            </div>
                          
        </div>


        </div>
                    </div>
                </div>
              
            </div>
    </section>

            </div>
  
           
        </div> 


    <script>
        $('input').parent('.custom-control-input').each(function () {
            var $this = $(this);
            var cssClass = $this.attr("class");
            var targetControl = $(this).parent().find('input');
            $(this).parent().find('label').addClass("custom-control-label");
            $(targetControl).addClass(cssClass).unwrap().parent('label[for],span').first().addClass(cssClass);
        });
    </script>
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <script src="userJs/bootstrap.bundle.min.js"></script>
    <script src="userJs/Chart.min.js"></script>
    <script src="userJs/sparkline.js"></script>
    <script src="userJs/jquery.vmap.min.js"></script>
    <script src="userJs/maps/jquery.vmap.usa.js"></script>
    <script src="userJs/jquery.knob.min.js"></script>
    <script src="userJs/moment.min.js"></script>
    <script src="userJs/daterangepicker.js"></script>
    <script src="userJs/tempusdominus-bootstrap-4.min.js"></script>
    <script src="userJs/summernote-bs4.min.js"></script>
    <script src="userJs/jquery.overlayScrollbars.min.js"></script>
    <script src="userJs/adminlte.js"></script>
    <script src="userJs/dashboard.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" type="text/css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- Bootstrap DatePicker -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   <script type="text/javascript"> 

$(function () {
  $("#id-1, #id-2, #id-3").keyup(function () {
    $("#id-4").val * (+$("#id-3").val
    (+$("#id-2").val() - +$("#id-1").val())) ;
  
    
  });
});
</script>


<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

 
 
<!-- page script -->
<script>

function copyFunc() {
  var copyText = document.getElementById("copyInp");
  copyText.select();
  document.execCommand("copy"); //this function copies the text of the input with ID "copyInp"
}


  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
 
  
 
var table= $('#example').DataTable();
var tableBody = '#example tbody';

    $(tableBody).on('click', 'tr', function () {
var cursor = table.row($(this));//get the clicked row
var data=cursor.data();// this will give you the data in the current row.
    $('form').find("input[name='username'][type='text']").val(data[0]);
    $('#modal_table').modal('close');
 
} );
</script>
 
</body>
</html>

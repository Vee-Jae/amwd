
	<!-- Add Payment TAB HTML -->
	<div id="editPaymentModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
					<form id="user_form_editPaymentModal">

				 <div class="modal-header">						
						<h4 class="modal-title">Add Payment Details</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				 </div>
					
				 
				 
				 <div class="modal-body">	
										<div class="row">
														<div class="col-sm-3">
															<label for="datepost">Account#: </label>
															<input type="text" id="id_u" name="id" class="form-control" required>		
															<input type="text" id="id_u1" name="id" value="<?php echo $themid; ?>" class="form-control" readonly>	
														</div>

														<div class="col-sm-9">
															<label for="datepost">Transaction Id: </label>
															<input type="text" id="trans_id" name="acctholder"  class="form-control" readonly>	
													</div>
												
										</div>
									<br> 
								

								
								
									<!--BILL PAYMENT-->	
									<CENTER> <b style color="#e90707;">PAY WATER BILL</b> </CENTER>
									<div class="form-group">
															<label for="datepost">Select Reading Date: </label>
														<select   class="form-control" name="select_readingdate"  aria-label="Default select example">
														<option value="" disabled>Select Date</option>
														<?php    if (!isset($_GET['dat']))
															{
																	$result = mysqli_query($conn , "SELECT * FROM tbl_reading_sched  where reading_date < '$thedatetoday' order by  id asc");
															}
																$cnt = 0 ;
																while( $row = mysqli_fetch_array($result) )
																{
																	$cnt++;

																	?>
																
																	<option value="<?php echo $row['reading_date']; ?>">
																	<?php 
																	echo $row['reading_date']; 
															?></option>
															<?php } ?>
														</select>
									</div>
								

							
											


									<div class="form-group">
											<label for="datepost">Payment Date:</label>
											<input type="date" class="form-control"  id="reading" name="payment_date">
									</div>

									<div class="form-group">
											<label> Amount:</label>
												<input type="number" name="waterbill_amount" min="0" placeholder="0" class="form-control" style="
												font-size: 40px;
												color: #ff0505;
												padding: 10px;
												font-weight: bold;
												text-align: center;
											" required>
									</div>

									<div class="form-group">
											<label>Mode of Payment:</label>
											<div class="form-check form-check-inline">
														<input class="form-check-input" type="radio" name="modeofpay" id="inlineRadio1" value="CASH">
														<label class="form-check-label" for="inlineRadio1"><b>CASH</b></label>
														</div>
														<div class="form-check form-check-inline">
														<input class="form-check-input" type="radio" name="modeofpay" id="inlineRadio2" value="GCASH">
														<label class="form-check-label" for="inlineRadio2"><b>G-CASH</b></label>
											</div>
														
											
									</div>
											
										<div class="modal-footer">
											<input type="hidden" value="5" name="type">
											<button type="button" class="btn btn-success btn-radius btn-block btn-multi text-white" id="btnupdate_wbpay">Submit Payment</button>				 
										</div>

									
									</form>
									
									<!--end BILL PAYMENT TAB--> 
									<center><a href="transactionhistory.php?mid=" onclick="this.href = this.href + document.getElementById('id_u').value;">[View Payment History]</a> </center>
									
					</div>				
			  
	</div>
	</div>
	</div>
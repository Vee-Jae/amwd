$( document ).ready(function() {
  $('#example1').SetEditable({
	  columnsEd: "0,1,2,3,4,5,6",
	  onEdit: function(columnsEd) {
		 // console.log("===edit=="+(this));
		var empId = columnsEd[0].childNodes[0].innerHTML;
        var type = columnsEd[0].childNodes[1].innerHTML;
        var reading = columnsEd[0].childNodes[2].innerHTML;
        var paid = columnsEd[0].childNodes[3].innerHTML;
        var mop = columnsEd[0].childNodes[4].innerHTML;
		var payment = columnsEd[0].childNodes[5].innerHTML;
		$.ajax({
			type: 'POST',			
			url : "action.php",	
			dataType: "json",					
			data: {id:empId, Type:type, reading:reading, paid:paid, mop:mop, payment:payment, action:'edit'},			
			success: function (response) {
				if(response.status) {
					// show update message
				}						
			}
		});
	  },
	  onBeforeDelete: function(columnsEd) {
	  var empId = columnsEd[0].childNodes[1].innerHTML;
	  $.ajax({
			type: 'POST',			
			url : "action.php",
			dataType: "json",					
			data: {id:empId, action:'delete'},			
			success: function (response) {
				if(response.status) {
					// show delete message
				}			
			}
		});
	  },
	});
});
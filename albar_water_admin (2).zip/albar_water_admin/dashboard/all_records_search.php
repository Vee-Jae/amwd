<section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
        <div class="table-responsive">
     
                <table id="example" class="table table-bordered table-hover">
              <thead>
                  <tr>
                   
                      <th >Reading Date</th>
                         <th >Account_no</th>
                        <th >Account Name</th>
                        <th >Previous Reading</th>
                        <th >Present Reading</th>
                        <th >Total Reading</th>
                        <th >Cubic</th>
                        <th >Payment Date</th>
                        <th >Billing Date</th>
                        <th >Amount Paid</th>
                        <th >Remaining Balance</th>
                        <th >Due Date</th>
                        <th >Disconnection Date</th>

                   
                    
                 </tr>
              </thead>
              <tbody>
                  <?php
                  
            $unique_id = $_GET['mid'];
                        $result = mysqli_query($conn , "SELECT * FROM tbl_members_report where account_no = '$unique_id'");
                   
                    $cnt = 0 ;
                    while( $row = mysqli_fetch_array($result) )
                    {
                        $cnt++;

                  ?>
                  <tr>
      
                       <td><?php echo $row['reading_date'] ?> </td>
                       <td> <?php echo $row['account_no'] ?></td>
                       <td> <?php echo $row['accoutn_name'] ?> </td>
                       <td><?php echo $row['prev_reading'] ?> </td>
                       <td><?php echo $row['pres_reading'] ?> </td>
                       <td><?php echo $row['total_reading'] ?> </td>
                       <td><?php echo $row['75_cubic'] ?> </td>
                       <td><?php echo $row['payment_date'] ?> </td>
                       <td><?php echo $row['billing_amount'] ?> </td>
                       <td><?php echo $row['amount_paid'] ?> </td>
                       <td><?php echo $row['balance'] ?> </td>
                       <td><?php echo $row['due_date'] ?> </td>


                 
                     
                  
                  </tr>
                  <?php
                    }
                  ?>
              </tbody>
              
          </table>
        </div>
        </div>
      </div>
    </div>
  </div>

</div>
</section>
<section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
            <?php
            if (!isset($_GET['dat']))
            {
                echo "<b>Unpaid Balances</b>" ;
            }
            else 
            ?>
        </h4>
     
                <table id="example1" class="table table-bordered table-hover">
              <thead>
                  <tr>
                   
                
                                   <th >reading_date</th>
                                  <th >account_no</th>
                                  <th >account_name</th>
                                
                                  <th >total_reading</th>  
                             
                              
                                  <th >billing_amount</th>
                                  <th >amount_paid</th>
                                  <th >balance</th>
                                  <th >due_date</th>
                               
                                  <th >Action</th>

                             
                 </tr>
              </thead>
              <tbody>
                  <?php
                   if (!isset($_GET['dat']))
                   {
                        $result = mysqli_query($conn , "SELECT * FROM tbl_members_report where balance != 0  Order by account_no DESC");
                   }
                    $cnt = 0 ;
                    while( $row = mysqli_fetch_array($result) )
                    {
                        $cnt++;

                  ?>
                  <tr>
              
                            
                            <td><?php echo $row['reading_date']; ?></td>
                                   
                                   <td><?php echo $row['account_no']; ?></td>
                                   <td><?php echo $row['account_name']; ?></td>
                                    <td><?php echo $row['total_reading']; ?>  </td> 
                              
                                   <td> &#8369;  <?php echo $row['billing_amount']; ?> </td>
                                   <td> &#8369; <?php echo $row['amount_paid']; ?>  </td>
                                   <td> <b style="color:red"> &#8369; <?php echo $row['balance']; ?> </b> </td>
                                   <td> &#8369;  <?php echo $row['due_date']; ?> </td>
                                   
                     
                      <td>
                     

                      <a href="paybalance.php?mid=<?php echo $row['unique_id'] ?>" 
                      class="btn btn-outline-success btn-radius" > <i class="fas fa-money-bill-alt"></i> </a>
                      

                     
                      <a href="profile.php?mid=<?php echo $row['unique_id'] ?>" class="btn btn-outline-dark btn-radius" > 
                      <i class="fas fa-edit"></i> </a>
                      
                    

                   


              <div class="modal" id="printcheckmodal">
            <div class="modal-dialog">
              <div class="modal-content btn-radius">
                <div class="modal-header pb-0" style="border: 0px;">
                  <h6 class="modal-title" style="font-weight: bold;">Print Cheque Format for: <br><p style="color:#f50d0d;font-size:18px;"> <?php
                   echo $row['fname'] . ' ' .$row['lname']  
                  ?> </p></h6>
                  
                </div> 
               
                <div class="modal-body pt-0 pb-0">
                <div class="col-12">

                <form method="POST" action="print.php?mid=<?php echo $row['id'] ?>" class="form-horizontal" id="quickForm" enctype="multipart/form-data">
                            
                
      <label for="datepost">Enter Cheque Date:</label>
  <input type="date" class="form-control"  id="postdate" name="postdate">
 

  <label for="datepost">Enter Amount:</label>
  <input type="number" class="form-control" id="inputName" name="check_numberformat" value="<?php echo $username; ?>" placeholder="">
                         
           
                        </div> 
                </div>

             
                <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                  <div class="row">
                    <div class="col-6">
                      <button type="button" class="btn btn-default btn-block btn-save bg-white" data-dismiss="modal">Cancel</button>
                    </div>
                    <div class="col-6">
                   <form>
                    <input type="hidden" name="save_data" value="<?php echo $row['id'] ?>">
                  
                      <input type="hidden" name="save_data" value="save">
                      <button type="submit" id="action" class="btn btn-warning btn-save btn-block">
                        <span id="button-text">Generate</span>
                      </button>

</form>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>



 

                      <div class="modal" id="requestModal">
            <div class="modal-dialog">
              <div class="modal-content btn-radius">
                <div class="modal-header pb-0" style="border: 0px;">
                  <h5 class="modal-title" style="font-weight: bold;">Remove Account</h5>
                </div>
                <div class="modal-body pt-0 pb-0">
                  <p class="text-muted">Are you sure you want to Remove This account?</p>
                </div>
                <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                  <div class="row">
                    <div class="col-6">
                      <button type="button" class="btn btn-default btn-block btn-save bg-white" data-dismiss="modal">Cancel</button>
                    </div>
                    <div class="col-6">
                   <form>
                    <input type="hidden" name="save_data" value="<?php echo $row['id'] ?>">
                  
                      <input type="hidden" name="save_data" value="save">
                      <button type="submit" id="action" class="btn btn-success btn-save btn-block">
                        <span id="button-text">Yes, Submit</span>
                      </button>

</form>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>

                      
                      
                      
                    </td>
                  </tr>
                  <?php
                    }
                  ?>
              </tbody>
              
          </table>
        </div>



       
      </div>
    </div>
  </div>

</div>
</section>
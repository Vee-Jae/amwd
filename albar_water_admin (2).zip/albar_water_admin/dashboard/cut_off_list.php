 
  <section class="content">
    <div class="container-fluid">
    <a href="add_new_reading.php?id=<?php echo $row_members['unique_id'] ?> "> [ Add Reading ] </a>
            <div class="card mt-3" style="border-radius: 10px; background-color: #1d2532; color: #fff;">
              <div class="card-body table-responsive p-3">
                  <table id="members_table" class="table table-striped">
                    <thead>
                    <tr> 
                      <th width="5%">reading_date</th>
                      <th>prev_reading</th>
                      <th>pres_reading</th>
                      <th>Total Reading</th>
                      <th>Payment date</th>
                      <th>Billing Amount</th>
                      <th>Amount Paid</th>
                      <th>Balance</th>
                      <th>Due Date</th>
                      <th>Disconnection</th>
                      <th>Action</th>
                       
                    </tr>
                    </thead>
                    <tbody>
                    <?php 
                      $sql_members = "SELECT * FROM tbl_members_report where account_no = '$unique_id' order by reading_date desc";
                      $result_members = $conn->query($sql_members);
                        while($row_members = mysqli_fetch_array($result_members)) {
                    ?>
                    <tr>
                      <td style="color: #ffd700;"><?php echo $row_members['reading_date']  ?></td>
                      <td style="color: #ffd700;"><?php echo $row_members['prev_reading'].'CM'; ?></td>
                      <td style="color: #ffd700;"><?php echo $row_members['pres_reading'].'CM'; ?></td>
                      <td style="color: #ffd700;"><?php echo $row_members['total_reading']; ?></td>
                      <td style="color: #ffd700;"><?php echo $row_members['payment_date']; ?></td>
                      <td style="color: #ffd700;"><?php echo '&#8369;'.$row_members['billing_amount']; ?></td>
                      <td style="color: #ffd700;"><?php echo '&#8369;'.$row_members['amount_paid']; ?></td>
                      <td style="color: #ffd700;"><?php echo '&#8369;'.$row_members['balance']; ?></td>

                      <td style="color: #ffd700;"><?php echo $row_members['due_date']; ?></td>
                      <td style="color: #ffd700;"><?php echo $row_members['disconnection_date']; ?></td>
                      <td style="color: #ffd700;"><a href="#">[ Edit ] </a><a href="#"> [Remove] </a></td>


                
                
                     
                    </tr>

          




                    <div class="modal" id="members<?php echo $row_members['unique_id']; ?>">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Member Summary Details</h5>
                          </div>
                          <div class="modal-body pt-2 pb-0">
                            <div class="txn-history">
                              <p class="txn-list">
                       
                                <span class="text-white">Account No: </span><span class="transaction-amount" style="color: #ffd700;"><?php echo $row_members['unique_id']; ?></span><br>
                              
                             
                              </p>

                            </div>
 
                          </div>

                          <div class="modal-footer" style="border: 0px">
                      
                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Add Reading</button>
                          </div>


                          <div class="modal-footer" style="border: 0px">
                          [ <a href="edit_profile.php?id=<?php echo $row_members['unique_id'] ?> "> Edit Account </a>]
                            <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>

    </div>
  </section> 
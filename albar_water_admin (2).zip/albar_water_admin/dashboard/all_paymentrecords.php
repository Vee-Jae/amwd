 


 

	<p id="success"></p>
  <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
				
					</div>
			 
                </div>
            </div>


   <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
            Collected  <b>Payment Records</b> 
        </h4>

		<form id="user_form_billspayment" action="" method="post" >
		<div class="form-group">
						<label for="datepost">Select Collection Date:</label>
       					 <input type="date" class="form-control"  id="reading" name="payment_date">
						</div>

						<label for="datepost">Payment for:</label>
						<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="payfor" id="inlineRadio3" value="all" checked>
									<label class="form-check-label" for="inlineRadio3"><b>All</b></label>
									</div>

									<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="payfor" id="inlineRadio1" value="WB">
									<label class="form-check-label" for="inlineRadio1"><b>WB</b></label>
									</div>
									<div class="form-check form-check-inline">
									<input class="form-check-input" type="radio" name="payfor" id="inlineRadio2" value="MB">
									<label class="form-check-label" for="inlineRadio2"><b>MB</b></label>
									
						 </div>
						<div class="modal-footer">
					 
						 <button type="submit" class="btn btn-primary btn-radius btn-block btn-multi text-white" name="btn-genfilter">Generate Report</button>
					 </div>	

</form>
                <table id="example1"  class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
             
                <thead>
                    <tr>
					<!--	<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th> -->
				 
						<th  >#</th>
						
					  <th  >Account</th>	
					  <th  >Acct Holder</th>				
                   
                      <th >Type</th>
					  <th> Amount Pay</th> 
					   <th >Payment Date</th>                   
                       <th >Reading Date</th>
                      <th width="20%" >Payment Option</th>
					  <th width="10%" >Action</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php

				if ($genpayment_date =='all') {
					$result = mysqli_query($conn," SELECT * FROM tbl_payments LEFT JOIN tbl_user_account ON tbl_user_account.unique_id = tbl_payments.unique_id  order by Reading_date desc");
				

				}else {
				$result = mysqli_query($conn,"SELECT * FROM tbl_payments LEFT JOIN tbl_user_account ON tbl_user_account.unique_id = tbl_payments.unique_id  where tbl_payments.payment_date = '$genpayment_date' or tbl_payments.payment_type = '$payfor' order by Reading_date desc");
			}
				
				$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
			 <tr id="<?php echo $i; ?>"> 
				<!--<td>
							<span class="custom-checkbox">
								<input type="checkbox" class="user_checkbox" data-user-id="<?php echo $row["id"]; ?>">
								<label for="checkbox2"></label>
							</span>
						</td> -->
					 
						<td><?php echo $i; ?></td>  

   <!--START OLD TABLE-->

   					<td><?php echo $row['unique_id'] ?></td>      
					   <td><?php echo $row['acct_holder'] ?></td>                    
                     
                      <td  >   <?php echo $row['payment_type'] ?>  </td>
                  
                     <td>   <?php echo $row['amount'] ?>	</td>
                     
                     <td> <?php echo $row['payment_date'] ?>   
                      </td>
                   

                         <td>  <?php echo $row['reading_date'] ?>  </td>
                     
                      <td> <?php echo $row['payment_option'] ?>  </td>

					  <td> 
               <a href="#deletebillspay" class="deletebillspay btn btn-danger btn-radius" data-id="<?php echo $row["id"]; ?>" data-toggle="modal">
		 <i class="fas fa-trash-alt" data-toggle="tooltip" 
			  title="Delete"></i></a>
                </td>


                      <!--END OLD TABLE-->
					 
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
	 
        </div>
    </div>
 
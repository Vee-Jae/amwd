
	<!-- Add Payment TAB HTML -->
	<div id="addmetertModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="user_form_meterreading">

                        <div class="modal-header">						
                            <h4 class="modal-title">Meter Reading Details</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                          </div>
				          	<div class="modal-body">	
                                            <div class="row">
                                                          <div class="col-sm-3">
                                                              <label for="datepost">Account#: </label>
                                                              <input type="text" id="id_u_reading" name="id" class="form-control" readonly>	
                                                       </div>
                                                                <div class="col-sm-8">
                                                                    <label for="datepost">Account Holder: </label>
                                                                    <input type="text" id="txt_acct_holder1" name="acctholder"  class="form-control" readonly>	
                                                                </div>
                                          </div>


                                          <div class="row">
                                                          <div class="col-sm-3">
                                                             
                                                              <input type="hidden" id="duedate" name="duedate" value="<?php echo $c_due_date; ?>" class="form-control" readonly>	
                                                       </div>
                                                                <div class="col-sm-8">
                                                                    
                                                                    <input type="hidden" id="disconnection" name="disconnection"  value="<?php echo $c_disconnection_date; ?>" class="form-control" readonly>	
                                                                </div>
                                          </div>


                     <br>
                                <div class="row">
                                          <div class="col-sm-3">
                                            <label for="datepost">Prev Reading: </label>
                                             <input type="number" id="id-1" name="prev_reading" min = "0" class="form-control" style=" background: transparent;"
                                              <?php if (($_SESSION['username'] == 'MainAdmin')) {
                                                
                                              }else {
                                                
                                                echo 'readonly';
                                              }?>
                                             
                                             />
                                            </div>
                                <div class="col-sm-9">
                                                <label for="datepost">New Reading Date:</label>
                                                    <input type="date" class="form-control"  id="postdate" name="postdate" value="<?php echo $c_readingdate?>" style=" background: transparent;
                                                    "   <?php if (($_SESSION['username'] == 'MainAdmin')) {
                                                
                                              }else {
                                                
                                                echo 'readonly';
                                              }?> />	 
                                                    <input type="hidden" name="first_num" id="first_num" required="required" value="<?php echo $first_num; ?>" /> 
                                </div>
		 
                       <br>
				
			 
                       <br>


                                <br>


 
                                        <div class="form-group"> 
                                          <div class="col-12">
                                                 <br><center>  <p style="
    background: #000;
    color: #ffe900;
    padding: 5px;
">   <b>Enter Present Reading: </b> </p>
                                                      <input type="number" name="newreading" id="id-2" class="form-control"  required="required"  style="
                                                      font-size: 20px;
                                                      font-weight: bold;
                                                      color: #eb0000;
                                                      text-align: center;
                                                  " required /> 
                                                      
                                                      <input type="hidden" min="0" readonly="readonly" name="reading_result" class="form-control"   id="id-3"  >   
                                                    <input type="hidden" value="75" readonly="readonly" name="reading_result_cubic" class="form-control"   id="id-4"  > 
                                                    <hr>
                                                  <b>Total Bill: </b>    </center>         
                                                    
                                                    <input type="number" readonly="readonly" name="reading_result_bill" class="form-control"   id="id-5"  value="0" style="text-align: center;border: none; background-color: transparent;font-weight: bold;color: #ff0c0c; font-size: 45px;" >  

                         <div class="modal-footer">
                          <input type="hidden" value="7" name="type">
                          <button type="button" class="btn btn-danger btn-radius btn-block btn-multi text-white" id="btn-addmeterreading">Submit Reading</button>
                        
                        </div>       
                                        </div> 
                                      </div>  
                     
             </div>
          
        </form>  
     
                  
        <center><a href="transactionhistory.php?mid=" onclick="this.href = this.href + document.getElementById('id_u_reading').value;">[View Readings History]</a> </center> 
                  
     </div>
  </div> 
 </div> 
                                            </div>


 


 

	<p id="success"></p>
  <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
				
					</div>
			 
                </div>
            </div>


   <section class="content">
<div class="container-fluid">
  
    <div class="col-lg-12 col-12">
      <div class="small-box bg-secondry shadow_block" style = " height: auto; width: 100%;" >
        <div class="inner">
            <h4 style="mx-auto" >
            Today  <b>Payment Collections</b>  &#8369;<?php echo number_format(($todaypayreceived));  ?>
        </h4>

	 
                <table id="example1"  class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
             
                <thead>
                    <tr>
					<!--	<th>
							<span class="custom-checkbox">
								<input type="checkbox" id="selectAll">
								<label for="selectAll"></label>
							</span>
						</th> -->
				 
						<th  >#</th>
						
					  <th  >Account</th>					
                      <th >Type</th>
					  <th> Amount Paid</th> 
					   <th >Payment Date</th>                   
                       <th >Reading Date</th>
					   <th >Date Encoded</th>
                      <th width="20%" >Action</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php
 
				$result = mysqli_query($conn,"SELECT tbl_user_account.unique_id,
				tbl_user_account.acct_holder,tbl_user_account.firstname,tbl_user_account.lastname,tbl_user_account.pres_reading,
				tbl_payments.payment_type,tbl_payments.amount,tbl_payments.payment_option,tbl_payments.reading_date,tbl_payments.collection_date,tbl_payments.payment_date  FROM tbl_user_account LEFT JOIN tbl_payments on 
				tbl_user_account.unique_id = tbl_payments.unique_id  where tbl_payments.payment_date = '$datetoday' order by tbl_payments.id desc ");
			 
				
				$i=1;
					while($row = mysqli_fetch_array($result)) {

					$unique_id      =	$row['unique_id'] ;
					$acct_holder    =	$row['acct_holder'] ;
					$firstname      =	$row['firstname'] ;
					$lastname       =	$row['lastname'] ;
					$pres_reading   =	$row['pres_reading']; 
					$payment_type   =	$row['payment_type'] ;
					$amount         =	$row['amount']; 
					$payment_option =	$row['payment_option'] ;
					$reading_date   =	$row['reading_date'] ;
					$payment_date   =	$row['payment_date'] ;
					$collection_date   =	$row['collection_date'] ;

				 
				?>
			 <tr id="<?php echo $i; ?>"> 
		 
					 
						<td><?php echo $i; ?></td>  

   <!--START OLD TABLE-->

   					<td><?php echo $row['unique_id'] ?></td>                    
                     
                      <td  >   <?php echo $row['payment_type'] ?>  </td>
                  
                     <td>   <?php echo $row['amount'] ?>	</td>
                     
                     <td> <?php echo $row['payment_date'] ?>   
                      </td>
					  <td> <?php echo $row['collection_date'] ?>   
                      </td>
                   

                         <td>  <?php echo $row['reading_date'] ?>  </td>
                     
                      <td> <a href="printreceipt.php?mid=<?php echo $unique_id; ?>&&acctholder=<?php echo $acct_holder;?>&&fname=<?php echo $firstname;?>&&lname=<?php echo $lastname;?>&&pres_reading=<?php echo $pres_reading;?>&&payment_type=<?php echo $payment_type;?>&&amount=<?php echo $amount;?>&&payment_option=<?php echo $payment_option;?>&&reading_date=<?php echo $reading_date;?>&&payment_date=<?php echo $payment_date;?>&&collection_date=<?php echo $collection_date;?>"><i class="fas fa-print"></i> </a></td>


                      <!--END OLD TABLE-->
					 
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
	 
        </div>
    </div>
 
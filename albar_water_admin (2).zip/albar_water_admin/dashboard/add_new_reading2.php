<?php
 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 $datetoday = date('Y-m-d'); 

 $unique_id = $_GET['id'];

$sql_user_details = "SELECT * FROM tbl_user_account WHERE unique_id = '$unique_id'";
$result_user_details = mysqli_query($conn, $sql_user_details);
$row_user_details = mysqli_fetch_assoc($result_user_details);
$username = $row_user_details['username'];
$firstname = $row_user_details['firstname'];
$homeadd = $row_user_details['home_address'];
 
$mi = $row_user_details['mi'];
 
$lastname = $row_user_details['lastname'];
 
$mobilenumber = $row_user_details['mobilenumber'];
$mobilenumber2 = $row_user_details['other_number'];
 

$message = '';
if (isset($_POST['save_changes'])) {
  $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
  $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
  $mobilenumber = mysqli_real_escape_string($conn, $_POST['mobilenumber']);
  $homeadd = mysqli_real_escape_string($conn, $_POST['homeadd']);
  $contact_persons = mysqli_real_escape_string($conn, $_POST['contact_persons']);
  $mobilenumber2 = mysqli_real_escape_string($conn, $_POST['mobilenumber2']);

  $sql_update = "UPDATE tbl_user_account SET firstname = '$firstname', lastname = '$lastname', 
  mobilenumber = '$mobilenumber', home_address= '$homeadd', other_number= '$mobilenumber2',username= '$contact_persons' WHERE unique_id = '$unique_id'";
  if (mysqli_query($conn, $sql_update)) {
    $message = '<div class="pb-4">
                  <span class="alert alert-success">Your profile details is successfully update</span>
                </div>';

  }
  
  
   
  $number_placement = $mobilenumber;
  $message_placement = urlencode("Hi ".$firstname."! Maari mo ng i-activate ang iyong AMWDS account");
   include_once ("sms_function.php");
  
  
}

?>  
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>add new  reading</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <link rel="icon" href="images/logo.png" type="image/png" sizes="16x16">
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="css/skeleton_loading.css">
<style type="text/css">
  .content-wrapper {
    background: #151e27!important;
  }
  @media(max-width:800px) {
    .modal-content {
      position: fixed; bottom: 40%; width: 96%; left: 7;
    }
    .modal-dialog {
      margin: 0!important; padding: 0!important;
    }
  }
  .btn {
    border-radius: 10px;
  }
  .form-control {
    border-radius: 10px;
  }
  .form-control:focus {
    border: 1px solid #ffd700!important;
  }
  .label {
    display: inline-block;
    margin-bottom: 0px !important;
    color: #fff!important;
    font-size: 80%!important;
    font-weight: 400!important;
  }
  .img-circle {
    border-color: grey;
  }
  .alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
  }
  .list-group-item {
    background: #1d2532!important;
    color: #fff!important;
  }
  .account-href {
    cursor: pointer; 
    display: block;
    color: #fff;
  }
  .account-href:hover {
    color: #fff;
  }
  .transaction-amount {
    float: right;
    color: #fff;
    font-weight: 800;
  }
  .transaction-number {
   float: right;
  }
  .form-control {
    border-radius: 10px;
  }
  .form-control:focus {
    border: 1px solid #ffd700!important;
  }
  @media(max-width:991px) {
    #order_full_screen {
      display: none!important;
    }
    #order_small_screen {
      display: block!important;
    }
  } 
</style>
</head>
<body class="hold-transition sidebar-mini layout-footer-fixed layout-fixed" style="background: #151e27;">
<div id="preloader" class="loading" style="display: none"></div>
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white" style="background: #151e27; border-bottom: 0; box-shadow: none!important;">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a href="account.php?<?php echo generate_string($permitted_chars, 100); ?>" class="withanimation"><i class="fas fa-angle-left pr-2" style="font-size: 20px; color: #ffd700;"></i></a><span class="brand-text" style="font-size: 20px;"><span style="font-size: 20px; font-weight: bolder; line-height: 20px; color: #fff;">Add New Reading</span></a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </ul>
  </nav>

<?php include ("navbar.php")?>
<div class="content-wrapper">
  <section class="content menu-main">
    <div class="container-fluid">
      <div class="pt-2"></div>
 
      <div class="text-center pt-2">
            <img id="logo_merchant"  class="profile-user-img img-fluid img-circle" src="dist/img/avatar5.png" alt="User profile picture">
            <p class="pt-1 text-white"><b><?php echo $username; ?></b><br>
              <span><small class="text-muted"><?php echo $unique_id; ?></small></span>
            </p>

            <span id="message">
              <?php echo $message; ?>
            </span>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <section class="content">
   

  
  <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Add New Reading</h3>
              </div>
              <div class="card-body">
              
              
           
                 
                 
<div class="row">

<div class="col-12">
<label class="label">Select Reading Date:</label>
<div class="input-group">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
  </div>
  <input type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask>
</div>
</div>
 
</div>
  



<div class="row"> 


<div class="col-3">

<label class="label">Previous Reading</label>
<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>" placeholder="Previous Reading" required/>
</div>


<div class="col-4">

<label class="label">Present Reading</label>
<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>" placeholder="Present Reading" required/>
</div>

<div class="col-5">

<label class="label">Total Reading</label>
<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>" placeholder="Total Reading" required/>
</div>

</div>





<div class="row"> 


<div class="col-3">
<label class="label">Payment  Date:</label>
<div class="input-group">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
  </div>
  <input type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask>
</div>
</div>


<div class="col-4">

<label class="label">Bill Amount</label>
<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>" placeholder="Bill Amount" required/>
</div>

<div class="col-5">

<label class="label">Amount Paid</label>
<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>" placeholder="Amount Paid" required/>
</div>

</div>









<div class="row"> 




<div class="col-3">

<label class="label">Remaining Balance</label>
<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>" placeholder="Bill Amount" required/>
</div>

<div class="col-4">

<label class="label">Due Date:</label>
<div class="input-group">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
  </div>
  <input type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask>
</div>
</div>

<div class="col-5">
<label class="label">Disconnection Date:</label>
<div class="input-group">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
  </div>
  <input type="text" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask>
</div>
</div>
 


 

              </div>
              <!-- /.card-body -->
   </div>


 
       



        <button type="button" data-toggle="modal" data-target="#update_info" class="btn btn-warning btn-block btn-lg" style="background: #FFD700; border-color: #ffd700;">Save Changes</button>

        <div class="modal" id="update_info">
          <div class="modal-dialog">
            <div class="modal-content" style="background-color: #151e27!important;">
              <div class="modal-header pb-0" style="border: 0px;">
                <h5 class="modal-title text-white" style="font-weight: bold;">Update</h5>
              </div>
              <div class="modal-body pt-0 pb-0">
                <p class="text-muted">Are you sure you want to update your info?</p>
              </div>
              <div class="modal-footer pr-0 pl-0 pb-2 pt-0" style="display: block; border: 0px">
                <div class="row">
                  <div class="col-6">
                    <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                  </div>
                  <div class="col-6">
                    <button type="submit" name="save_changes" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div> <!-- logout -->

      </form>
    </div>

    <br>
  </section>
  [
  <?php include('cut_off_list.php')?>
 

</div>
</div>



<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>


<script src="dist/js/demo.js"></script>
<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('yyyy/mm/dd', { 'placeholder': 'yyyy/mm/dd' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('yyyy/mm/dd', { 'placeholder': 'yyyy/mm/dd' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservationdate').datetimepicker({
        format: 'L'
    });
    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'YYYY/MM/DD'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })
    
    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })

  </script> 

 

 
</body>
</html>

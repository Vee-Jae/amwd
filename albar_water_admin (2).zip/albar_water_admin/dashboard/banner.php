<?php
 session_start();
 require_once('../connect.php');
 require_once('sql_required.php');

 $datetoday = date('Y-m-d'); 
$active_tab = "members";
if (!isset($_SESSION['unique_id'])) { ?>
    <script language="javascript">
      window.location.href = '../index.php';
    </script>
<?php }


$message = '';
if (isset($_POST['save'])) {
  $rand = rand();
  $bannerID = $_POST['banner_id'];

  if ($_FILES['update_banner']['name'] == '') {
    $file_store_bannerpic = $_POST['banner_img'];
  }else{
    $reupload_banner_pic = $rand.'_'.$_FILES['update_banner']['name'];
    $file_item_loc_bannerpic = $_FILES['update_banner']['tmp_name'];
    $file_store_bannerpic = "banner/".$reupload_banner_pic;
  }

  $sqlProfile = "UPDATE tbl_banner SET banner_img = '$file_store_bannerpic' WHERE id = '$bannerID'";
  if (mysqli_query($conn, $sqlProfile)) {
    if ($_FILES['update_banner']['name'] != '') {
      move_uploaded_file($file_item_loc_bannerpic , '../dashboard/'.$file_store_bannerpic);
    }
    $message = '<div class="pb-1">
                  <div class="alert alert-success"><center>Successfully Update Banner!</center></div>
                </div>';
  }
}


if (isset($_POST['add_new'])) {
  $upload_banner = rand().'_'.$_FILES['upload_banner']['name'];
    $file_item_loc_bannerpic = $_FILES['upload_banner']['tmp_name'];
    $file_store_bannerpic = "banner/".$upload_banner;

    $sqlInsert = "INSERT INTO tbl_banner(banner_img) VALUES('$file_store_bannerpic')";
    if(mysqli_query($conn, $sqlInsert)) {
    move_uploaded_file($file_item_loc_bannerpic , '../dashboard/'.$file_store_bannerpic);
    $message = '<div class="pb-1">
                  <div class="alert alert-success"><center>Successfully Upload Banner!</center></div>
                </div>';
    }
}
?>  
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Members</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <link rel="icon" href="images/logo.png" type="image/png" sizes="16x16">
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style1.css">
  <link rel="stylesheet" type="text/css" href="css/skeleton_loading.css">
<style type="text/css">
  .content-wrapper {
    background: #151e27!important;
  }
  @media(max-width:800px) {
    .modal-content {
      position: fixed; bottom: 40%; width: 96%; left: 7;
    }
    .modal-dialog {
      margin: 0!important; padding: 0!important;
    }
  }
  .page-item.active .page-link {
    background-color: #27313d!important;
    border-color: #27313d!important;
    color: #000;
  }
  .page-item .page-link {
    background-color: #151e27!important;
    border-color: grey!important;
    color: grey!important;
  }
  .txn-history {
    text-align: left;
  }
  .txn-list {
    background-color: #1d2532;
    padding: 12px 10px; 
    color: #777;
    font-size: 14px;
    margin: 7px 0;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12)!important;
    cursor: pointer;
  }
  .transaction-amount {
    float: right;
    color: #fff;
    font-weight: 800;
  }
  .transaction-number {
   float: right;
  }
  .form-control {
    border-radius: 10px;
  }
  .form-control:focus {
    border: 1px solid #ffd700!important;
  }
  @media(max-width:991px) {
    #order_full_screen {
      display: none!important;
    }
    #order_small_screen {
      display: block!important;
    }
  }
</style>
</head>
<body class="hold-transition sidebar-mini layout-footer-fixed layout-fixed" style="background: #151e27;">
<div id="preloader" class="loading" style="display: none"></div>
<div class="wrapper">
  <nav class="main-header navbar navbar-expand navbar-white" style="background: #151e27; border-bottom: 0; box-shadow: none!important;">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a href="index.php?<?php echo generate_string($permitted_chars, 100); ?>" class="withanimation back_arrow"><i class="fas fa-angle-left pr-2" style="font-size: 20px; color: #ffd700;"></i></a><span class="brand-text" style="font-size: 20px;"><span style="font-size: 20px; font-weight: bolder; line-height: 20px; color: #fff;">Members List</span></a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </ul>
  </nav>

<?php include ("navbar.php")?>
<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">

    <span id="message">
        <?php echo $message; ?>
      </span>


            <div class="card mt-3" style="border-radius: 10px; background-color: #1d2532; color: #fff;">
              <div class="card-body table-responsive p-3">

                    <div align="right" class="mb-4">
        <button type="button" data-toggle="modal" data-target="#addBanner" class="btn btn-success btn-sm">Add Banner</button>
      </div>
                  <table id="members_table" class="table table-striped">
                    <thead>
                    <tr>
                      <th width="5%">ID</th>
                      <th>Banner</th>
                      <th width="20%">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php 
                      $sqlBanner = "SELECT * FROM tbl_banner ORDER BY id DESC";
                      $resultBanner = $conn->query($sqlBanner);
                        while($rowBanner = mysqli_fetch_array($resultBanner)) {
                    ?>
                    <tr>
                      <td style="color: #ffd700;"><?php echo $rowBanner['id']; ?></td>
                      <td><img src="../dashboard/<?php echo $rowBanner['banner_img']; ?>" width="100" height="80"></td>
                      <td>
                        <a data-toggle="modal" data-target="#updateBanner" data-banner-id="<?php echo $rowBanner['id']; ?>" data-old-image="<?php echo $rowBanner['banner_img']; ?>" class="btn btn-sm btn-info updateBtn">Update Banner</a>
                        <a href="removeBanner.php?id=<?php echo $rowBanner['id']; ?>" class="btn btn-sm btn-danger">Remove</a>
                      </td>
                    </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>


    </div>
  </section>
</div>
</div>
                    <div class="modal" id="updateBanner">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Update Banner</h5>
                          </div>
                          <form class="m-0" method="POST" enctype="multipart/form-data">
                            <div class="modal-body pt-2 pb-0">
                              <input type="file" class="form-control-file text-white" accept="image/*" name="update_banner" required>
                            </div>
                            <div class="modal-footer pr-0 pl-0 pb-2 pt-3" style="display: block; border: 0px">
                              <div class="row">
                                <div class="col-6">
                                  <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                                </div>
                                <div class="col-6">
                                  <input type="hidden" id="bannerID" name="banner_id">
                                  <input type="hidden" id="bannerImg" name="banner_img">
                                  <button type="submit" name="save" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>


                    <div class="modal" id="addBanner">
                      <div class="modal-dialog">
                        <div class="modal-content" style="background-color: #151e27!important;">
                          <div class="modal-header pb-0" style="border: 0px;">
                            <h5 class="modal-title text-white" style="font-weight: bold;">Add Banner</h5>
                          </div>
                          <form class="m-0" method="POST" enctype="multipart/form-data">
                            <div class="modal-body pt-2 pb-0">
                              <input type="file" class="form-control-file text-white" accept="image/*" name="upload_banner" required>
                            </div>
                            <div class="modal-footer pr-0 pl-0 pb-2 pt-3" style="display: block; border: 0px">
                              <div class="row">
                                <div class="col-6">
                                  <button type="button" class="btn btn-default btn-lg btn-block" style="background: transparent; color: #fff;" data-dismiss="modal">Cancel</button>
                                </div>
                                <div class="col-6">
                                  <button type="submit" name="add_new" class="btn btn-warning btn-lg btn-block withanimation_submit" style="background: #FFD700; border-color: #ffd700;">Yes, Submit</button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>


<script src="dist/js/adminlte.min.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="plugins/jquery-validation/additional-methods.min.js"></script>
<script src="dist/js/pages/dashboard.js"></script>
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  $('.updateBtn').click(function() {
    var id = $(this).attr('data-banner-id');
    var old_image = $(this).attr('data-old-image');
    $('#bannerImg').val(old_image);
    $('#bannerID').val(id);
  });
});
$(function () {
  $("#members_table").DataTable({
    "responsive": true,
    "autoWidth": false,
  });
  $(".withanimation").click(function(e) {
      e.preventDefault();
      $(".loading").show();
      var url=$(this).attr("href");
      setTimeout(function() {
          window.location=url;
      }, 500);
  });
});

if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>


</body>
</html>

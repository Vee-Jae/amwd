 
$(document).on("click", ".update", function (e) {
  var id = "test3";
 
 
  $("#id_u").val(id);
 
});


 

 

$(document).on("click", "#update", function (e) {
  var data = $("#editPaymentModal").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "all_members_save.php",
    success: function (dataResult) {
      var dataResult = JSON.parse(dataResult);
      if (dataResult.statusCode == 200) {
        $("#editEmployeeModal").modal("hide");
        swal("Good job!", "Data Updated Successfully!", "success");
        setTimeout(2000);
        location.reload();
      } else if (dataResult.statusCode == 201) {
        swal("Error!", "Could'not be Updated !", "Warnings");
        setTimeout(2000);
      }
    },
  });
});
 